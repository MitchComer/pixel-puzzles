gdjs._48pingpongCode = {};
gdjs._48pingpongCode.GD0pingpongObjects1= [];
gdjs._48pingpongCode.GD0pingpongObjects2= [];
gdjs._48pingpongCode.GDarrowObjects1= [];
gdjs._48pingpongCode.GDarrowObjects2= [];
gdjs._48pingpongCode.GDarrow2Objects1= [];
gdjs._48pingpongCode.GDarrow2Objects2= [];
gdjs._48pingpongCode.GDtileObjects1= [];
gdjs._48pingpongCode.GDtileObjects2= [];
gdjs._48pingpongCode.GDguide2Objects1= [];
gdjs._48pingpongCode.GDguide2Objects2= [];
gdjs._48pingpongCode.GDguideObjects1= [];
gdjs._48pingpongCode.GDguideObjects2= [];
gdjs._48pingpongCode.GDpaddleObjects1= [];
gdjs._48pingpongCode.GDpaddleObjects2= [];
gdjs._48pingpongCode.GDpaddleanimatonObjects1= [];
gdjs._48pingpongCode.GDpaddleanimatonObjects2= [];
gdjs._48pingpongCode.GDstringanimationObjects1= [];
gdjs._48pingpongCode.GDstringanimationObjects2= [];
gdjs._48pingpongCode.GDstringObjects1= [];
gdjs._48pingpongCode.GDstringObjects2= [];
gdjs._48pingpongCode.GDwateranimationObjects1= [];
gdjs._48pingpongCode.GDwateranimationObjects2= [];
gdjs._48pingpongCode.GDwaterObjects1= [];
gdjs._48pingpongCode.GDwaterObjects2= [];
gdjs._48pingpongCode.GDdptObjects1= [];
gdjs._48pingpongCode.GDdptObjects2= [];
gdjs._48pingpongCode.GDpeeObjects1= [];
gdjs._48pingpongCode.GDpeeObjects2= [];
gdjs._48pingpongCode.GDnext2Objects1= [];
gdjs._48pingpongCode.GDnext2Objects2= [];
gdjs._48pingpongCode.GDnextObjects1= [];
gdjs._48pingpongCode.GDnextObjects2= [];
gdjs._48pingpongCode.GDhintObjects1= [];
gdjs._48pingpongCode.GDhintObjects2= [];

gdjs._48pingpongCode.conditionTrue_0 = {val:false};
gdjs._48pingpongCode.condition0IsTrue_0 = {val:false};
gdjs._48pingpongCode.condition1IsTrue_0 = {val:false};
gdjs._48pingpongCode.condition2IsTrue_0 = {val:false};
gdjs._48pingpongCode.condition3IsTrue_0 = {val:false};


gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDarrowObjects1Objects = Hashtable.newFrom({"arrow": gdjs._48pingpongCode.GDarrowObjects1});gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDarrow2Objects1Objects = Hashtable.newFrom({"arrow2": gdjs._48pingpongCode.GDarrow2Objects1});gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDpaddleObjects1Objects = Hashtable.newFrom({"paddle": gdjs._48pingpongCode.GDpaddleObjects1});gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDwaterObjects1Objects = Hashtable.newFrom({"water": gdjs._48pingpongCode.GDwaterObjects1});gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDstringObjects1Objects = Hashtable.newFrom({"string": gdjs._48pingpongCode.GDstringObjects1});gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDdptObjects1Objects = Hashtable.newFrom({"dpt": gdjs._48pingpongCode.GDdptObjects1});gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDnext2Objects1Objects = Hashtable.newFrom({"next2": gdjs._48pingpongCode.GDnext2Objects1});gdjs._48pingpongCode.eventsList0xb4320 = function(runtimeScene) {

{


gdjs._48pingpongCode.condition0IsTrue_0.val = false;
gdjs._48pingpongCode.condition1IsTrue_0.val = false;
{
gdjs._48pingpongCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._48pingpongCode.condition0IsTrue_0.val ) {
{
gdjs._48pingpongCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "1");
}}
if (gdjs._48pingpongCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio\\Click-SoundBible.com-1387633738.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "1");
}}

}


{


gdjs._48pingpongCode.condition0IsTrue_0.val = false;
{
gdjs._48pingpongCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 2);
}if (gdjs._48pingpongCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


{


gdjs._48pingpongCode.condition0IsTrue_0.val = false;
{
gdjs._48pingpongCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1);
}if (gdjs._48pingpongCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Photon.mp3", 2, false, 100, 1);
}}

}


{


gdjs._48pingpongCode.condition0IsTrue_0.val = false;
{
gdjs._48pingpongCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 60, "60");
}if (gdjs._48pingpongCode.condition0IsTrue_0.val) {
gdjs._48pingpongCode.GDhintObjects1.createFrom(runtimeScene.getObjects("hint"));
{for(var i = 0, len = gdjs._48pingpongCode.GDhintObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDhintObjects1[i].hide(false);
}
}}

}


{


gdjs._48pingpongCode.condition0IsTrue_0.val = false;
{
gdjs._48pingpongCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._48pingpongCode.condition0IsTrue_0.val) {
gdjs._48pingpongCode.GDhintObjects1.createFrom(runtimeScene.getObjects("hint"));
{for(var i = 0, len = gdjs._48pingpongCode.GDhintObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDhintObjects1[i].hide();
}
}}

}


{


gdjs._48pingpongCode.condition0IsTrue_0.val = false;
{
gdjs._48pingpongCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._48pingpongCode.condition0IsTrue_0.val) {
{gdjs.adMob.loadBanner("ca-app-pub-6927019777720724/2829692216", "", true, true, true, false);
}}

}


{


gdjs._48pingpongCode.condition0IsTrue_0.val = false;
{
gdjs._48pingpongCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._48pingpongCode.condition0IsTrue_0.val) {
gdjs._48pingpongCode.GDarrow2Objects1.createFrom(runtimeScene.getObjects("arrow2"));
gdjs._48pingpongCode.GDdptObjects1.createFrom(runtimeScene.getObjects("dpt"));
gdjs._48pingpongCode.GDguideObjects1.createFrom(runtimeScene.getObjects("guide"));
gdjs._48pingpongCode.GDguide2Objects1.createFrom(runtimeScene.getObjects("guide2"));
gdjs._48pingpongCode.GDnextObjects1.createFrom(runtimeScene.getObjects("next"));
gdjs._48pingpongCode.GDnext2Objects1.createFrom(runtimeScene.getObjects("next2"));
gdjs._48pingpongCode.GDpaddleanimatonObjects1.createFrom(runtimeScene.getObjects("paddleanimaton"));
gdjs._48pingpongCode.GDpeeObjects1.createFrom(runtimeScene.getObjects("pee"));
gdjs._48pingpongCode.GDstringObjects1.createFrom(runtimeScene.getObjects("string"));
gdjs._48pingpongCode.GDstringanimationObjects1.createFrom(runtimeScene.getObjects("stringanimation"));
gdjs._48pingpongCode.GDtileObjects1.createFrom(runtimeScene.getObjects("tile"));
gdjs._48pingpongCode.GDwateranimationObjects1.createFrom(runtimeScene.getObjects("wateranimation"));
{for(var i = 0, len = gdjs._48pingpongCode.GDarrow2Objects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDarrow2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDtileObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDtileObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDguide2Objects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDguide2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDguideObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDguideObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDpaddleanimatonObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDpaddleanimatonObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDstringanimationObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDstringanimationObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDstringObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDstringObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDwateranimationObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDwateranimationObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDdptObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDdptObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDpeeObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDpeeObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDpeeObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDpeeObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDnext2Objects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDnext2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDnextObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDnextObjects1[i].hide();
}
}}

}


{

gdjs._48pingpongCode.GDarrowObjects1.createFrom(runtimeScene.getObjects("arrow"));

gdjs._48pingpongCode.condition0IsTrue_0.val = false;
gdjs._48pingpongCode.condition1IsTrue_0.val = false;
{
gdjs._48pingpongCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDarrowObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48pingpongCode.condition0IsTrue_0.val ) {
{
gdjs._48pingpongCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48pingpongCode.condition1IsTrue_0.val) {
/* Reuse gdjs._48pingpongCode.GDarrowObjects1 */
gdjs._48pingpongCode.GDarrow2Objects1.createFrom(runtimeScene.getObjects("arrow2"));
gdjs._48pingpongCode.GDguideObjects1.createFrom(runtimeScene.getObjects("guide"));
gdjs._48pingpongCode.GDguide2Objects1.createFrom(runtimeScene.getObjects("guide2"));
gdjs._48pingpongCode.GDtileObjects1.createFrom(runtimeScene.getObjects("tile"));
{for(var i = 0, len = gdjs._48pingpongCode.GDarrowObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDarrowObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDtileObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDtileObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDguide2Objects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDguide2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDguideObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDguideObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDarrow2Objects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDarrow2Objects1[i].hide(false);
}
}}

}


{

gdjs._48pingpongCode.GDarrow2Objects1.createFrom(runtimeScene.getObjects("arrow2"));

gdjs._48pingpongCode.condition0IsTrue_0.val = false;
gdjs._48pingpongCode.condition1IsTrue_0.val = false;
{
gdjs._48pingpongCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDarrow2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48pingpongCode.condition0IsTrue_0.val ) {
{
gdjs._48pingpongCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48pingpongCode.condition1IsTrue_0.val) {
gdjs._48pingpongCode.GDarrowObjects1.createFrom(runtimeScene.getObjects("arrow"));
/* Reuse gdjs._48pingpongCode.GDarrow2Objects1 */
gdjs._48pingpongCode.GDguideObjects1.createFrom(runtimeScene.getObjects("guide"));
gdjs._48pingpongCode.GDguide2Objects1.createFrom(runtimeScene.getObjects("guide2"));
gdjs._48pingpongCode.GDtileObjects1.createFrom(runtimeScene.getObjects("tile"));
{for(var i = 0, len = gdjs._48pingpongCode.GDarrowObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDarrowObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDtileObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDtileObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDguide2Objects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDguide2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDguideObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDguideObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDarrow2Objects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDarrow2Objects1[i].hide();
}
}}

}


{

gdjs._48pingpongCode.GDpaddleObjects1.createFrom(runtimeScene.getObjects("paddle"));

gdjs._48pingpongCode.condition0IsTrue_0.val = false;
gdjs._48pingpongCode.condition1IsTrue_0.val = false;
{
gdjs._48pingpongCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDpaddleObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48pingpongCode.condition0IsTrue_0.val ) {
{
gdjs._48pingpongCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48pingpongCode.condition1IsTrue_0.val) {
gdjs._48pingpongCode.GDpaddleanimatonObjects1.createFrom(runtimeScene.getObjects("paddleanimaton"));
{for(var i = 0, len = gdjs._48pingpongCode.GDpaddleanimatonObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDpaddleanimatonObjects1[i].playAnimation();
}
}}

}


{

gdjs._48pingpongCode.GDwaterObjects1.createFrom(runtimeScene.getObjects("water"));

gdjs._48pingpongCode.condition0IsTrue_0.val = false;
gdjs._48pingpongCode.condition1IsTrue_0.val = false;
{
gdjs._48pingpongCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDwaterObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48pingpongCode.condition0IsTrue_0.val ) {
{
gdjs._48pingpongCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48pingpongCode.condition1IsTrue_0.val) {
gdjs._48pingpongCode.GDwateranimationObjects1.createFrom(runtimeScene.getObjects("wateranimation"));
{for(var i = 0, len = gdjs._48pingpongCode.GDwateranimationObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDwateranimationObjects1[i].playAnimation();
}
}}

}


{

gdjs._48pingpongCode.GDstringObjects1.createFrom(runtimeScene.getObjects("string"));

gdjs._48pingpongCode.condition0IsTrue_0.val = false;
gdjs._48pingpongCode.condition1IsTrue_0.val = false;
{
gdjs._48pingpongCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDstringObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48pingpongCode.condition0IsTrue_0.val ) {
{
gdjs._48pingpongCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48pingpongCode.condition1IsTrue_0.val) {
gdjs._48pingpongCode.GDstringanimationObjects1.createFrom(runtimeScene.getObjects("stringanimation"));
{for(var i = 0, len = gdjs._48pingpongCode.GDstringanimationObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDstringanimationObjects1[i].playAnimation();
}
}}

}


{

gdjs._48pingpongCode.GDpaddleanimatonObjects1.createFrom(runtimeScene.getObjects("paddleanimaton"));

gdjs._48pingpongCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48pingpongCode.GDpaddleanimatonObjects1.length;i<l;++i) {
    if ( gdjs._48pingpongCode.GDpaddleanimatonObjects1[i].hasAnimationEnded() ) {
        gdjs._48pingpongCode.condition0IsTrue_0.val = true;
        gdjs._48pingpongCode.GDpaddleanimatonObjects1[k] = gdjs._48pingpongCode.GDpaddleanimatonObjects1[i];
        ++k;
    }
}
gdjs._48pingpongCode.GDpaddleanimatonObjects1.length = k;}if (gdjs._48pingpongCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "0pingpong", false);
}}

}


{

gdjs._48pingpongCode.GDstringanimationObjects1.createFrom(runtimeScene.getObjects("stringanimation"));

gdjs._48pingpongCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48pingpongCode.GDstringanimationObjects1.length;i<l;++i) {
    if ( gdjs._48pingpongCode.GDstringanimationObjects1[i].hasAnimationEnded() ) {
        gdjs._48pingpongCode.condition0IsTrue_0.val = true;
        gdjs._48pingpongCode.GDstringanimationObjects1[k] = gdjs._48pingpongCode.GDstringanimationObjects1[i];
        ++k;
    }
}
gdjs._48pingpongCode.GDstringanimationObjects1.length = k;}if (gdjs._48pingpongCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "0pingpong", false);
}}

}


{

gdjs._48pingpongCode.GDwateranimationObjects1.createFrom(runtimeScene.getObjects("wateranimation"));

gdjs._48pingpongCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48pingpongCode.GDwateranimationObjects1.length;i<l;++i) {
    if ( gdjs._48pingpongCode.GDwateranimationObjects1[i].hasAnimationEnded() ) {
        gdjs._48pingpongCode.condition0IsTrue_0.val = true;
        gdjs._48pingpongCode.GDwateranimationObjects1[k] = gdjs._48pingpongCode.GDwateranimationObjects1[i];
        ++k;
    }
}
gdjs._48pingpongCode.GDwateranimationObjects1.length = k;}if (gdjs._48pingpongCode.condition0IsTrue_0.val) {
gdjs._48pingpongCode.GDdptObjects1.createFrom(runtimeScene.getObjects("dpt"));
gdjs._48pingpongCode.GDpeeObjects1.createFrom(runtimeScene.getObjects("pee"));
{for(var i = 0, len = gdjs._48pingpongCode.GDdptObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDdptObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDpeeObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDpeeObjects1[i].hide(false);
}
}}

}


{

gdjs._48pingpongCode.GDdptObjects1.createFrom(runtimeScene.getObjects("dpt"));

gdjs._48pingpongCode.condition0IsTrue_0.val = false;
gdjs._48pingpongCode.condition1IsTrue_0.val = false;
gdjs._48pingpongCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48pingpongCode.GDdptObjects1.length;i<l;++i) {
    if ( gdjs._48pingpongCode.GDdptObjects1[i].isVisible() ) {
        gdjs._48pingpongCode.condition0IsTrue_0.val = true;
        gdjs._48pingpongCode.GDdptObjects1[k] = gdjs._48pingpongCode.GDdptObjects1[i];
        ++k;
    }
}
gdjs._48pingpongCode.GDdptObjects1.length = k;}if ( gdjs._48pingpongCode.condition0IsTrue_0.val ) {
{
gdjs._48pingpongCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDdptObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48pingpongCode.condition1IsTrue_0.val ) {
{
gdjs._48pingpongCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48pingpongCode.condition2IsTrue_0.val) {
gdjs._48pingpongCode.GDpeeObjects1.createFrom(runtimeScene.getObjects("pee"));
{for(var i = 0, len = gdjs._48pingpongCode.GDpeeObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDpeeObjects1[i].playAnimation();
}
}}

}


{

gdjs._48pingpongCode.GDpeeObjects1.createFrom(runtimeScene.getObjects("pee"));

gdjs._48pingpongCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48pingpongCode.GDpeeObjects1.length;i<l;++i) {
    if ( gdjs._48pingpongCode.GDpeeObjects1[i].hasAnimationEnded() ) {
        gdjs._48pingpongCode.condition0IsTrue_0.val = true;
        gdjs._48pingpongCode.GDpeeObjects1[k] = gdjs._48pingpongCode.GDpeeObjects1[i];
        ++k;
    }
}
gdjs._48pingpongCode.GDpeeObjects1.length = k;}if (gdjs._48pingpongCode.condition0IsTrue_0.val) {
gdjs._48pingpongCode.GDnextObjects1.createFrom(runtimeScene.getObjects("next"));
gdjs._48pingpongCode.GDnext2Objects1.createFrom(runtimeScene.getObjects("next2"));
{for(var i = 0, len = gdjs._48pingpongCode.GDnext2Objects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDnext2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48pingpongCode.GDnextObjects1.length ;i < len;++i) {
    gdjs._48pingpongCode.GDnextObjects1[i].hide(false);
}
}}

}


{

gdjs._48pingpongCode.GDnext2Objects1.createFrom(runtimeScene.getObjects("next2"));

gdjs._48pingpongCode.condition0IsTrue_0.val = false;
gdjs._48pingpongCode.condition1IsTrue_0.val = false;
gdjs._48pingpongCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48pingpongCode.GDnext2Objects1.length;i<l;++i) {
    if ( gdjs._48pingpongCode.GDnext2Objects1[i].isVisible() ) {
        gdjs._48pingpongCode.condition0IsTrue_0.val = true;
        gdjs._48pingpongCode.GDnext2Objects1[k] = gdjs._48pingpongCode.GDnext2Objects1[i];
        ++k;
    }
}
gdjs._48pingpongCode.GDnext2Objects1.length = k;}if ( gdjs._48pingpongCode.condition0IsTrue_0.val ) {
{
gdjs._48pingpongCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48pingpongCode.mapOfGDgdjs_46_9548pingpongCode_46GDnext2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48pingpongCode.condition1IsTrue_0.val ) {
{
gdjs._48pingpongCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48pingpongCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "0camel", false);
}}

}


}; //End of gdjs._48pingpongCode.eventsList0xb4320


gdjs._48pingpongCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._48pingpongCode.GD0pingpongObjects1.length = 0;
gdjs._48pingpongCode.GD0pingpongObjects2.length = 0;
gdjs._48pingpongCode.GDarrowObjects1.length = 0;
gdjs._48pingpongCode.GDarrowObjects2.length = 0;
gdjs._48pingpongCode.GDarrow2Objects1.length = 0;
gdjs._48pingpongCode.GDarrow2Objects2.length = 0;
gdjs._48pingpongCode.GDtileObjects1.length = 0;
gdjs._48pingpongCode.GDtileObjects2.length = 0;
gdjs._48pingpongCode.GDguide2Objects1.length = 0;
gdjs._48pingpongCode.GDguide2Objects2.length = 0;
gdjs._48pingpongCode.GDguideObjects1.length = 0;
gdjs._48pingpongCode.GDguideObjects2.length = 0;
gdjs._48pingpongCode.GDpaddleObjects1.length = 0;
gdjs._48pingpongCode.GDpaddleObjects2.length = 0;
gdjs._48pingpongCode.GDpaddleanimatonObjects1.length = 0;
gdjs._48pingpongCode.GDpaddleanimatonObjects2.length = 0;
gdjs._48pingpongCode.GDstringanimationObjects1.length = 0;
gdjs._48pingpongCode.GDstringanimationObjects2.length = 0;
gdjs._48pingpongCode.GDstringObjects1.length = 0;
gdjs._48pingpongCode.GDstringObjects2.length = 0;
gdjs._48pingpongCode.GDwateranimationObjects1.length = 0;
gdjs._48pingpongCode.GDwateranimationObjects2.length = 0;
gdjs._48pingpongCode.GDwaterObjects1.length = 0;
gdjs._48pingpongCode.GDwaterObjects2.length = 0;
gdjs._48pingpongCode.GDdptObjects1.length = 0;
gdjs._48pingpongCode.GDdptObjects2.length = 0;
gdjs._48pingpongCode.GDpeeObjects1.length = 0;
gdjs._48pingpongCode.GDpeeObjects2.length = 0;
gdjs._48pingpongCode.GDnext2Objects1.length = 0;
gdjs._48pingpongCode.GDnext2Objects2.length = 0;
gdjs._48pingpongCode.GDnextObjects1.length = 0;
gdjs._48pingpongCode.GDnextObjects2.length = 0;
gdjs._48pingpongCode.GDhintObjects1.length = 0;
gdjs._48pingpongCode.GDhintObjects2.length = 0;

gdjs._48pingpongCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['_48pingpongCode'] = gdjs._48pingpongCode;
