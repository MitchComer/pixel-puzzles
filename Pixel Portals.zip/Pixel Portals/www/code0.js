gdjs.IntroCode = {};
gdjs.IntroCode.GDbackgroundObjects1= [];
gdjs.IntroCode.GDbackgroundObjects2= [];
gdjs.IntroCode.GDPPP22Objects1= [];
gdjs.IntroCode.GDPPP22Objects2= [];
gdjs.IntroCode.GDPPP2Objects1= [];
gdjs.IntroCode.GDPPP2Objects2= [];
gdjs.IntroCode.GDPPP3Objects1= [];
gdjs.IntroCode.GDPPP3Objects2= [];
gdjs.IntroCode.GDPPPObjects1= [];
gdjs.IntroCode.GDPPPObjects2= [];
gdjs.IntroCode.GDNameObjects1= [];
gdjs.IntroCode.GDNameObjects2= [];
gdjs.IntroCode.GDArrow2Objects1= [];
gdjs.IntroCode.GDArrow2Objects2= [];
gdjs.IntroCode.GDArrowObjects1= [];
gdjs.IntroCode.GDArrowObjects2= [];
gdjs.IntroCode.GDNAMELINEObjects1= [];
gdjs.IntroCode.GDNAMELINEObjects2= [];
gdjs.IntroCode.GDStart2Objects1= [];
gdjs.IntroCode.GDStart2Objects2= [];
gdjs.IntroCode.GDStartObjects1= [];
gdjs.IntroCode.GDStartObjects2= [];

gdjs.IntroCode.conditionTrue_0 = {val:false};
gdjs.IntroCode.condition0IsTrue_0 = {val:false};
gdjs.IntroCode.condition1IsTrue_0 = {val:false};
gdjs.IntroCode.condition2IsTrue_0 = {val:false};


gdjs.IntroCode.mapOfGDgdjs_46IntroCode_46GDStartObjects1Objects = Hashtable.newFrom({"Start": gdjs.IntroCode.GDStartObjects1});gdjs.IntroCode.mapOfGDgdjs_46IntroCode_46GDArrowObjects1Objects = Hashtable.newFrom({"Arrow": gdjs.IntroCode.GDArrowObjects1});gdjs.IntroCode.mapOfGDgdjs_46IntroCode_46GDArrow2Objects1Objects = Hashtable.newFrom({"Arrow2": gdjs.IntroCode.GDArrow2Objects1});gdjs.IntroCode.eventsList0xb4320 = function(runtimeScene) {

{


gdjs.IntroCode.condition0IsTrue_0.val = false;
{
gdjs.IntroCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.IntroCode.condition0IsTrue_0.val) {
gdjs.IntroCode.GDArrow2Objects1.createFrom(runtimeScene.getObjects("Arrow2"));
gdjs.IntroCode.GDNAMELINEObjects1.createFrom(runtimeScene.getObjects("NAMELINE"));
gdjs.IntroCode.GDNameObjects1.createFrom(runtimeScene.getObjects("Name"));
{for(var i = 0, len = gdjs.IntroCode.GDArrow2Objects1.length ;i < len;++i) {
    gdjs.IntroCode.GDArrow2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.IntroCode.GDNameObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDNameObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.IntroCode.GDNAMELINEObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDNAMELINEObjects1[i].hide();
}
}}

}


{

gdjs.IntroCode.GDStartObjects1.createFrom(runtimeScene.getObjects("Start"));

gdjs.IntroCode.condition0IsTrue_0.val = false;
gdjs.IntroCode.condition1IsTrue_0.val = false;
{
gdjs.IntroCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.IntroCode.condition0IsTrue_0.val ) {
{
gdjs.IntroCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.IntroCode.mapOfGDgdjs_46IntroCode_46GDStartObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.IntroCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1LightBulb", false);
}}

}


{

gdjs.IntroCode.GDArrowObjects1.createFrom(runtimeScene.getObjects("Arrow"));

gdjs.IntroCode.condition0IsTrue_0.val = false;
gdjs.IntroCode.condition1IsTrue_0.val = false;
{
gdjs.IntroCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.IntroCode.mapOfGDgdjs_46IntroCode_46GDArrowObjects1Objects, runtimeScene, true, false);
}if ( gdjs.IntroCode.condition0IsTrue_0.val ) {
{
gdjs.IntroCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.IntroCode.condition1IsTrue_0.val) {
/* Reuse gdjs.IntroCode.GDArrowObjects1 */
gdjs.IntroCode.GDArrow2Objects1.createFrom(runtimeScene.getObjects("Arrow2"));
gdjs.IntroCode.GDNAMELINEObjects1.createFrom(runtimeScene.getObjects("NAMELINE"));
gdjs.IntroCode.GDNameObjects1.createFrom(runtimeScene.getObjects("Name"));
{for(var i = 0, len = gdjs.IntroCode.GDNameObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDNameObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.IntroCode.GDArrow2Objects1.length ;i < len;++i) {
    gdjs.IntroCode.GDArrow2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.IntroCode.GDNAMELINEObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDNAMELINEObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.IntroCode.GDArrowObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDArrowObjects1[i].hide();
}
}}

}


{

gdjs.IntroCode.GDArrow2Objects1.createFrom(runtimeScene.getObjects("Arrow2"));

gdjs.IntroCode.condition0IsTrue_0.val = false;
gdjs.IntroCode.condition1IsTrue_0.val = false;
{
gdjs.IntroCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.IntroCode.mapOfGDgdjs_46IntroCode_46GDArrow2Objects1Objects, runtimeScene, true, false);
}if ( gdjs.IntroCode.condition0IsTrue_0.val ) {
{
gdjs.IntroCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.IntroCode.condition1IsTrue_0.val) {
gdjs.IntroCode.GDArrowObjects1.createFrom(runtimeScene.getObjects("Arrow"));
/* Reuse gdjs.IntroCode.GDArrow2Objects1 */
gdjs.IntroCode.GDNAMELINEObjects1.createFrom(runtimeScene.getObjects("NAMELINE"));
gdjs.IntroCode.GDNameObjects1.createFrom(runtimeScene.getObjects("Name"));
{for(var i = 0, len = gdjs.IntroCode.GDNAMELINEObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDNAMELINEObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.IntroCode.GDNameObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDNameObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.IntroCode.GDArrow2Objects1.length ;i < len;++i) {
    gdjs.IntroCode.GDArrow2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.IntroCode.GDArrowObjects1.length ;i < len;++i) {
    gdjs.IntroCode.GDArrowObjects1[i].hide(false);
}
}}

}


{


gdjs.IntroCode.condition0IsTrue_0.val = false;
gdjs.IntroCode.condition1IsTrue_0.val = false;
{
gdjs.IntroCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.IntroCode.condition0IsTrue_0.val ) {
{
gdjs.IntroCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "1");
}}
if (gdjs.IntroCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio\\Click-SoundBible.com-1387633738.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "1");
}}

}


{


gdjs.IntroCode.condition0IsTrue_0.val = false;
{
gdjs.IntroCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.IntroCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


{


gdjs.IntroCode.condition0IsTrue_0.val = false;
{
gdjs.IntroCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1);
}if (gdjs.IntroCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Photon.mp3", 2, false, 100, 1);
}}

}


{


gdjs.IntroCode.condition0IsTrue_0.val = false;
{
gdjs.IntroCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 2);
}if (gdjs.IntroCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


}; //End of gdjs.IntroCode.eventsList0xb4320


gdjs.IntroCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.IntroCode.GDbackgroundObjects1.length = 0;
gdjs.IntroCode.GDbackgroundObjects2.length = 0;
gdjs.IntroCode.GDPPP22Objects1.length = 0;
gdjs.IntroCode.GDPPP22Objects2.length = 0;
gdjs.IntroCode.GDPPP2Objects1.length = 0;
gdjs.IntroCode.GDPPP2Objects2.length = 0;
gdjs.IntroCode.GDPPP3Objects1.length = 0;
gdjs.IntroCode.GDPPP3Objects2.length = 0;
gdjs.IntroCode.GDPPPObjects1.length = 0;
gdjs.IntroCode.GDPPPObjects2.length = 0;
gdjs.IntroCode.GDNameObjects1.length = 0;
gdjs.IntroCode.GDNameObjects2.length = 0;
gdjs.IntroCode.GDArrow2Objects1.length = 0;
gdjs.IntroCode.GDArrow2Objects2.length = 0;
gdjs.IntroCode.GDArrowObjects1.length = 0;
gdjs.IntroCode.GDArrowObjects2.length = 0;
gdjs.IntroCode.GDNAMELINEObjects1.length = 0;
gdjs.IntroCode.GDNAMELINEObjects2.length = 0;
gdjs.IntroCode.GDStart2Objects1.length = 0;
gdjs.IntroCode.GDStart2Objects2.length = 0;
gdjs.IntroCode.GDStartObjects1.length = 0;
gdjs.IntroCode.GDStartObjects2.length = 0;

gdjs.IntroCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['IntroCode'] = gdjs.IntroCode;
