gdjs._48camelCode = {};
gdjs._48camelCode.GDdesertObjects1= [];
gdjs._48camelCode.GDdesertObjects2= [];
gdjs._48camelCode.GDnext2Objects1= [];
gdjs._48camelCode.GDnext2Objects2= [];
gdjs._48camelCode.GDnextObjects1= [];
gdjs._48camelCode.GDnextObjects2= [];
gdjs._48camelCode.GDguide2Objects1= [];
gdjs._48camelCode.GDguide2Objects2= [];
gdjs._48camelCode.GDguideObjects1= [];
gdjs._48camelCode.GDguideObjects2= [];
gdjs._48camelCode.GDbarObjects1= [];
gdjs._48camelCode.GDbarObjects2= [];

gdjs._48camelCode.conditionTrue_0 = {val:false};
gdjs._48camelCode.condition0IsTrue_0 = {val:false};
gdjs._48camelCode.condition1IsTrue_0 = {val:false};
gdjs._48camelCode.condition2IsTrue_0 = {val:false};


gdjs._48camelCode.mapOfGDgdjs_46_9548camelCode_46GDnext2Objects1Objects = Hashtable.newFrom({"next2": gdjs._48camelCode.GDnext2Objects1});gdjs._48camelCode.eventsList0xb4320 = function(runtimeScene) {

{


gdjs._48camelCode.condition0IsTrue_0.val = false;
{
gdjs._48camelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._48camelCode.condition0IsTrue_0.val) {
{gdjs.adMob.loadBanner("ca-app-pub-6927019777720724/2829692216", "", true, true, true, false);
}}

}


{


gdjs._48camelCode.condition0IsTrue_0.val = false;
gdjs._48camelCode.condition1IsTrue_0.val = false;
{
gdjs._48camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._48camelCode.condition0IsTrue_0.val ) {
{
gdjs._48camelCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "1");
}}
if (gdjs._48camelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio\\Click-SoundBible.com-1387633738.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "1");
}}

}


{


gdjs._48camelCode.condition0IsTrue_0.val = false;
{
gdjs._48camelCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 2);
}if (gdjs._48camelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


{


gdjs._48camelCode.condition0IsTrue_0.val = false;
{
gdjs._48camelCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1);
}if (gdjs._48camelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Photon.mp3", 2, false, 100, 1);
}}

}


{

gdjs._48camelCode.GDnext2Objects1.createFrom(runtimeScene.getObjects("next2"));

gdjs._48camelCode.condition0IsTrue_0.val = false;
gdjs._48camelCode.condition1IsTrue_0.val = false;
{
gdjs._48camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48camelCode.mapOfGDgdjs_46_9548camelCode_46GDnext2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48camelCode.condition0IsTrue_0.val ) {
{
gdjs._48camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48camelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1camel", false);
}}

}


}; //End of gdjs._48camelCode.eventsList0xb4320


gdjs._48camelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._48camelCode.GDdesertObjects1.length = 0;
gdjs._48camelCode.GDdesertObjects2.length = 0;
gdjs._48camelCode.GDnext2Objects1.length = 0;
gdjs._48camelCode.GDnext2Objects2.length = 0;
gdjs._48camelCode.GDnextObjects1.length = 0;
gdjs._48camelCode.GDnextObjects2.length = 0;
gdjs._48camelCode.GDguide2Objects1.length = 0;
gdjs._48camelCode.GDguide2Objects2.length = 0;
gdjs._48camelCode.GDguideObjects1.length = 0;
gdjs._48camelCode.GDguideObjects2.length = 0;
gdjs._48camelCode.GDbarObjects1.length = 0;
gdjs._48camelCode.GDbarObjects2.length = 0;

gdjs._48camelCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['_48camelCode'] = gdjs._48camelCode;
