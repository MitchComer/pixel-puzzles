gdjs._50camelCode = {};
gdjs._50camelCode.GDNewObjectObjects1= [];
gdjs._50camelCode.GDNewObjectObjects2= [];
gdjs._50camelCode.GDguide2Objects1= [];
gdjs._50camelCode.GDguide2Objects2= [];
gdjs._50camelCode.GDguideObjects1= [];
gdjs._50camelCode.GDguideObjects2= [];
gdjs._50camelCode.GDNewObject2Objects1= [];
gdjs._50camelCode.GDNewObject2Objects2= [];
gdjs._50camelCode.GDguy1Objects1= [];
gdjs._50camelCode.GDguy1Objects2= [];
gdjs._50camelCode.GDguy2Objects1= [];
gdjs._50camelCode.GDguy2Objects2= [];
gdjs._50camelCode.GDcamel2Objects1= [];
gdjs._50camelCode.GDcamel2Objects2= [];
gdjs._50camelCode.GDcamelObjects1= [];
gdjs._50camelCode.GDcamelObjects2= [];
gdjs._50camelCode.GDcamel3Objects1= [];
gdjs._50camelCode.GDcamel3Objects2= [];
gdjs._50camelCode.GDcamel4Objects1= [];
gdjs._50camelCode.GDcamel4Objects2= [];
gdjs._50camelCode.GDcamel5Objects1= [];
gdjs._50camelCode.GDcamel5Objects2= [];
gdjs._50camelCode.GDcamel6Objects1= [];
gdjs._50camelCode.GDcamel6Objects2= [];
gdjs._50camelCode.GDcamel7Objects1= [];
gdjs._50camelCode.GDcamel7Objects2= [];
gdjs._50camelCode.GDcamel8Objects1= [];
gdjs._50camelCode.GDcamel8Objects2= [];
gdjs._50camelCode.GDtownObjects1= [];
gdjs._50camelCode.GDtownObjects2= [];
gdjs._50camelCode.GDnext2Objects1= [];
gdjs._50camelCode.GDnext2Objects2= [];
gdjs._50camelCode.GDnext3Objects1= [];
gdjs._50camelCode.GDnext3Objects2= [];
gdjs._50camelCode.GDnext4Objects1= [];
gdjs._50camelCode.GDnext4Objects2= [];
gdjs._50camelCode.GDnextObjects1= [];
gdjs._50camelCode.GDnextObjects2= [];
gdjs._50camelCode.GDNewObject3Objects1= [];
gdjs._50camelCode.GDNewObject3Objects2= [];
gdjs._50camelCode.GDhintObjects1= [];
gdjs._50camelCode.GDhintObjects2= [];

gdjs._50camelCode.conditionTrue_0 = {val:false};
gdjs._50camelCode.condition0IsTrue_0 = {val:false};
gdjs._50camelCode.condition1IsTrue_0 = {val:false};
gdjs._50camelCode.condition2IsTrue_0 = {val:false};
gdjs._50camelCode.condition3IsTrue_0 = {val:false};


gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDguy1Objects1Objects = Hashtable.newFrom({"guy1": gdjs._50camelCode.GDguy1Objects1});gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel2Objects1Objects = Hashtable.newFrom({"camel2": gdjs._50camelCode.GDcamel2Objects1});gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDtownObjects1Objects = Hashtable.newFrom({"town": gdjs._50camelCode.GDtownObjects1});gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDnext2Objects1Objects = Hashtable.newFrom({"next2": gdjs._50camelCode.GDnext2Objects1});gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDnext3Objects1Objects = Hashtable.newFrom({"next3": gdjs._50camelCode.GDnext3Objects1});gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDguy2Objects1Objects = Hashtable.newFrom({"guy2": gdjs._50camelCode.GDguy2Objects1});gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel4Objects1Objects = Hashtable.newFrom({"camel4": gdjs._50camelCode.GDcamel4Objects1});gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamelObjects1Objects = Hashtable.newFrom({"camel": gdjs._50camelCode.GDcamelObjects1});gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel5Objects1Objects = Hashtable.newFrom({"camel5": gdjs._50camelCode.GDcamel5Objects1});gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel6Objects1Objects = Hashtable.newFrom({"camel6": gdjs._50camelCode.GDcamel6Objects1});gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel7Objects1Objects = Hashtable.newFrom({"camel7": gdjs._50camelCode.GDcamel7Objects1});gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel8Objects1Objects = Hashtable.newFrom({"camel8": gdjs._50camelCode.GDcamel8Objects1});gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel3Objects1Objects = Hashtable.newFrom({"camel3": gdjs._50camelCode.GDcamel3Objects1});gdjs._50camelCode.eventsList0x75b834 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "2camel", false);
}}

}


}; //End of gdjs._50camelCode.eventsList0x75b834
gdjs._50camelCode.eventsList0x759acc = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "2camel", false);
}}

}


}; //End of gdjs._50camelCode.eventsList0x759acc
gdjs._50camelCode.eventsList0xb4320 = function(runtimeScene) {

{


gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "1");
}}
if (gdjs._50camelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio\\Click-SoundBible.com-1387633738.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "1");
}}

}


{


gdjs._50camelCode.condition0IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 2);
}if (gdjs._50camelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


{


gdjs._50camelCode.condition0IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1);
}if (gdjs._50camelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Photon.mp3", 2, false, 100, 1);
}}

}


{


gdjs._50camelCode.condition0IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._50camelCode.condition0IsTrue_0.val) {
gdjs._50camelCode.GDcamelObjects1.createFrom(runtimeScene.getObjects("camel"));
gdjs._50camelCode.GDcamel2Objects1.createFrom(runtimeScene.getObjects("camel2"));
gdjs._50camelCode.GDcamel3Objects1.createFrom(runtimeScene.getObjects("camel3"));
gdjs._50camelCode.GDcamel4Objects1.createFrom(runtimeScene.getObjects("camel4"));
gdjs._50camelCode.GDcamel5Objects1.createFrom(runtimeScene.getObjects("camel5"));
gdjs._50camelCode.GDcamel6Objects1.createFrom(runtimeScene.getObjects("camel6"));
gdjs._50camelCode.GDcamel7Objects1.createFrom(runtimeScene.getObjects("camel7"));
gdjs._50camelCode.GDcamel8Objects1.createFrom(runtimeScene.getObjects("camel8"));
gdjs._50camelCode.GDguy1Objects1.createFrom(runtimeScene.getObjects("guy1"));
gdjs._50camelCode.GDguy2Objects1.createFrom(runtimeScene.getObjects("guy2"));
gdjs._50camelCode.GDnextObjects1.createFrom(runtimeScene.getObjects("next"));
gdjs._50camelCode.GDnext2Objects1.createFrom(runtimeScene.getObjects("next2"));
gdjs._50camelCode.GDtownObjects1.createFrom(runtimeScene.getObjects("town"));
{for(var i = 0, len = gdjs._50camelCode.GDnext2Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDnext2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._50camelCode.GDnextObjects1.length ;i < len;++i) {
    gdjs._50camelCode.GDnextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._50camelCode.GDtownObjects1.length ;i < len;++i) {
    gdjs._50camelCode.GDtownObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._50camelCode.GDguy1Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDguy1Objects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._50camelCode.GDguy2Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDguy2Objects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._50camelCode.GDcamelObjects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamelObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._50camelCode.GDcamel2Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel2Objects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._50camelCode.GDcamel3Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel3Objects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._50camelCode.GDcamel4Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel4Objects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._50camelCode.GDcamel5Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel5Objects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._50camelCode.GDcamel6Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel6Objects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._50camelCode.GDcamel7Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel7Objects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._50camelCode.GDcamel8Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel8Objects1[i].pauseAnimation();
}
}{gdjs.adMob.loadBanner("ca-app-pub-6927019777720724/2829692216", "", true, true, true, false);
}}

}


{

gdjs._50camelCode.GDguy1Objects1.createFrom(runtimeScene.getObjects("guy1"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDguy1Objects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._50camelCode.condition1IsTrue_0.val) {
/* Reuse gdjs._50camelCode.GDguy1Objects1 */
{for(var i = 0, len = gdjs._50camelCode.GDguy1Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDguy1Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel2Objects1.createFrom(runtimeScene.getObjects("camel2"));
gdjs._50camelCode.GDguy1Objects1.createFrom(runtimeScene.getObjects("guy1"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
gdjs._50camelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDguy1Objects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDguy1Objects1[i].hasAnimationEnded() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDguy1Objects1[k] = gdjs._50camelCode.GDguy1Objects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDguy1Objects1.length = k;}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition1IsTrue_0.val ) {
{
gdjs._50camelCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._50camelCode.condition2IsTrue_0.val) {
/* Reuse gdjs._50camelCode.GDcamel2Objects1 */
{for(var i = 0, len = gdjs._50camelCode.GDcamel2Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel2Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel2Objects1.createFrom(runtimeScene.getObjects("camel2"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDcamel2Objects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDcamel2Objects1[i].hasAnimationEnded() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDcamel2Objects1[k] = gdjs._50camelCode.GDcamel2Objects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDcamel2Objects1.length = k;}if (gdjs._50camelCode.condition0IsTrue_0.val) {
gdjs._50camelCode.GDtownObjects1.createFrom(runtimeScene.getObjects("town"));
{for(var i = 0, len = gdjs._50camelCode.GDtownObjects1.length ;i < len;++i) {
    gdjs._50camelCode.GDtownObjects1[i].hide(false);
}
}}

}


{

gdjs._50camelCode.GDtownObjects1.createFrom(runtimeScene.getObjects("town"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
gdjs._50camelCode.condition2IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDtownObjects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._50camelCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDtownObjects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDtownObjects1[i].isVisible() ) {
        gdjs._50camelCode.condition2IsTrue_0.val = true;
        gdjs._50camelCode.GDtownObjects1[k] = gdjs._50camelCode.GDtownObjects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDtownObjects1.length = k;}}
}
if (gdjs._50camelCode.condition2IsTrue_0.val) {
gdjs._50camelCode.GDnextObjects1.createFrom(runtimeScene.getObjects("next"));
gdjs._50camelCode.GDnext2Objects1.createFrom(runtimeScene.getObjects("next2"));
{for(var i = 0, len = gdjs._50camelCode.GDnextObjects1.length ;i < len;++i) {
    gdjs._50camelCode.GDnextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._50camelCode.GDnext2Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDnext2Objects1[i].hide(false);
}
}}

}


{

gdjs._50camelCode.GDnext2Objects1.createFrom(runtimeScene.getObjects("next2"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
gdjs._50camelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDnext2Objects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDnext2Objects1[i].isVisible() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDnext2Objects1[k] = gdjs._50camelCode.GDnext2Objects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDnext2Objects1.length = k;}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDnext2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition1IsTrue_0.val ) {
{
gdjs._50camelCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._50camelCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "0black", false);
}}

}


{

gdjs._50camelCode.GDnext3Objects1.createFrom(runtimeScene.getObjects("next3"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
gdjs._50camelCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDnext3Objects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDnext3Objects1[i].isVisible() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDnext3Objects1[k] = gdjs._50camelCode.GDnext3Objects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDnext3Objects1.length = k;}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDnext3Objects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition1IsTrue_0.val ) {
{
gdjs._50camelCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._50camelCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1camel", false);
}}

}


{

gdjs._50camelCode.GDguy2Objects1.createFrom(runtimeScene.getObjects("guy2"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDguy2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._50camelCode.condition1IsTrue_0.val) {
/* Reuse gdjs._50camelCode.GDguy2Objects1 */
{for(var i = 0, len = gdjs._50camelCode.GDguy2Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDguy2Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel4Objects1.createFrom(runtimeScene.getObjects("camel4"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel4Objects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._50camelCode.condition1IsTrue_0.val) {
/* Reuse gdjs._50camelCode.GDcamel4Objects1 */
{for(var i = 0, len = gdjs._50camelCode.GDcamel4Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel4Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamelObjects1.createFrom(runtimeScene.getObjects("camel"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamelObjects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._50camelCode.condition1IsTrue_0.val) {
/* Reuse gdjs._50camelCode.GDcamelObjects1 */
{for(var i = 0, len = gdjs._50camelCode.GDcamelObjects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamelObjects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel5Objects1.createFrom(runtimeScene.getObjects("camel5"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel5Objects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._50camelCode.condition1IsTrue_0.val) {
/* Reuse gdjs._50camelCode.GDcamel5Objects1 */
{for(var i = 0, len = gdjs._50camelCode.GDcamel5Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel5Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel6Objects1.createFrom(runtimeScene.getObjects("camel6"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel6Objects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._50camelCode.condition1IsTrue_0.val) {
/* Reuse gdjs._50camelCode.GDcamel6Objects1 */
{for(var i = 0, len = gdjs._50camelCode.GDcamel6Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel6Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel7Objects1.createFrom(runtimeScene.getObjects("camel7"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel7Objects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._50camelCode.condition1IsTrue_0.val) {
/* Reuse gdjs._50camelCode.GDcamel7Objects1 */
{for(var i = 0, len = gdjs._50camelCode.GDcamel7Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel7Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel8Objects1.createFrom(runtimeScene.getObjects("camel8"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel8Objects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._50camelCode.condition1IsTrue_0.val) {
/* Reuse gdjs._50camelCode.GDcamel8Objects1 */
{for(var i = 0, len = gdjs._50camelCode.GDcamel8Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel8Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel3Objects1.createFrom(runtimeScene.getObjects("camel3"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50camelCode.mapOfGDgdjs_46_9550camelCode_46GDcamel3Objects1Objects, runtimeScene, true, false);
}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._50camelCode.condition1IsTrue_0.val) {
/* Reuse gdjs._50camelCode.GDcamel3Objects1 */
{for(var i = 0, len = gdjs._50camelCode.GDcamel3Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel3Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamelObjects1.createFrom(runtimeScene.getObjects("camel"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDcamelObjects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDcamelObjects1[i].hasAnimationEnded() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDcamelObjects1[k] = gdjs._50camelCode.GDcamelObjects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDcamelObjects1.length = k;}if (gdjs._50camelCode.condition0IsTrue_0.val) {
gdjs._50camelCode.GDcamel7Objects1.createFrom(runtimeScene.getObjects("camel7"));
gdjs._50camelCode.GDcamel8Objects1.createFrom(runtimeScene.getObjects("camel8"));
{for(var i = 0, len = gdjs._50camelCode.GDcamel8Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel8Objects1[i].playAnimation();
}
}{for(var i = 0, len = gdjs._50camelCode.GDcamel7Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel7Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel3Objects1.createFrom(runtimeScene.getObjects("camel3"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDcamel3Objects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDcamel3Objects1[i].hasAnimationEnded() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDcamel3Objects1[k] = gdjs._50camelCode.GDcamel3Objects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDcamel3Objects1.length = k;}if (gdjs._50camelCode.condition0IsTrue_0.val) {
gdjs._50camelCode.GDcamel5Objects1.createFrom(runtimeScene.getObjects("camel5"));
{for(var i = 0, len = gdjs._50camelCode.GDcamel5Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel5Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel4Objects1.createFrom(runtimeScene.getObjects("camel4"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDcamel4Objects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDcamel4Objects1[i].hasAnimationEnded() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDcamel4Objects1[k] = gdjs._50camelCode.GDcamel4Objects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDcamel4Objects1.length = k;}if (gdjs._50camelCode.condition0IsTrue_0.val) {
gdjs._50camelCode.GDcamel5Objects1.createFrom(runtimeScene.getObjects("camel5"));
{for(var i = 0, len = gdjs._50camelCode.GDcamel5Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel5Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel5Objects1.createFrom(runtimeScene.getObjects("camel5"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDcamel5Objects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDcamel5Objects1[i].hasAnimationEnded() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDcamel5Objects1[k] = gdjs._50camelCode.GDcamel5Objects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDcamel5Objects1.length = k;}if (gdjs._50camelCode.condition0IsTrue_0.val) {
gdjs._50camelCode.GDcamel7Objects1.createFrom(runtimeScene.getObjects("camel7"));
{for(var i = 0, len = gdjs._50camelCode.GDcamel7Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel7Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel6Objects1.createFrom(runtimeScene.getObjects("camel6"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDcamel6Objects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDcamel6Objects1[i].hasAnimationEnded() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDcamel6Objects1[k] = gdjs._50camelCode.GDcamel6Objects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDcamel6Objects1.length = k;}if (gdjs._50camelCode.condition0IsTrue_0.val) {
gdjs._50camelCode.GDcamel3Objects1.createFrom(runtimeScene.getObjects("camel3"));
{for(var i = 0, len = gdjs._50camelCode.GDcamel3Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel3Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel7Objects1.createFrom(runtimeScene.getObjects("camel7"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDcamel7Objects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDcamel7Objects1[i].hasAnimationEnded() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDcamel7Objects1[k] = gdjs._50camelCode.GDcamel7Objects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDcamel7Objects1.length = k;}if (gdjs._50camelCode.condition0IsTrue_0.val) {
gdjs._50camelCode.GDcamel4Objects1.createFrom(runtimeScene.getObjects("camel4"));
{for(var i = 0, len = gdjs._50camelCode.GDcamel4Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel4Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel8Objects1.createFrom(runtimeScene.getObjects("camel8"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDcamel8Objects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDcamel8Objects1[i].hasAnimationEnded() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDcamel8Objects1[k] = gdjs._50camelCode.GDcamel8Objects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDcamel8Objects1.length = k;}if (gdjs._50camelCode.condition0IsTrue_0.val) {
gdjs._50camelCode.GDcamel5Objects1.createFrom(runtimeScene.getObjects("camel5"));
{for(var i = 0, len = gdjs._50camelCode.GDcamel5Objects1.length ;i < len;++i) {
    gdjs._50camelCode.GDcamel5Objects1[i].playAnimation();
}
}}

}


{

gdjs._50camelCode.GDcamel8Objects1.createFrom(runtimeScene.getObjects("camel8"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDcamel8Objects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDcamel8Objects1[i].hasAnimationEnded() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDcamel8Objects1[k] = gdjs._50camelCode.GDcamel8Objects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDcamel8Objects1.length = k;}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 10, "5");
}}
if (gdjs._50camelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "5");
}
{ //Subevents
gdjs._50camelCode.eventsList0x75b834(runtimeScene);} //End of subevents
}

}


{

gdjs._50camelCode.GDguy2Objects1.createFrom(runtimeScene.getObjects("guy2"));

gdjs._50camelCode.condition0IsTrue_0.val = false;
gdjs._50camelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._50camelCode.GDguy2Objects1.length;i<l;++i) {
    if ( gdjs._50camelCode.GDguy2Objects1[i].hasAnimationEnded() ) {
        gdjs._50camelCode.condition0IsTrue_0.val = true;
        gdjs._50camelCode.GDguy2Objects1[k] = gdjs._50camelCode.GDguy2Objects1[i];
        ++k;
    }
}
gdjs._50camelCode.GDguy2Objects1.length = k;}if ( gdjs._50camelCode.condition0IsTrue_0.val ) {
{
gdjs._50camelCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 12, "2");
}}
if (gdjs._50camelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "2");
}
{ //Subevents
gdjs._50camelCode.eventsList0x759acc(runtimeScene);} //End of subevents
}

}


{


gdjs._50camelCode.condition0IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 60, "60");
}if (gdjs._50camelCode.condition0IsTrue_0.val) {
gdjs._50camelCode.GDhintObjects1.createFrom(runtimeScene.getObjects("hint"));
{for(var i = 0, len = gdjs._50camelCode.GDhintObjects1.length ;i < len;++i) {
    gdjs._50camelCode.GDhintObjects1[i].hide(false);
}
}}

}


{


gdjs._50camelCode.condition0IsTrue_0.val = false;
{
gdjs._50camelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._50camelCode.condition0IsTrue_0.val) {
gdjs._50camelCode.GDhintObjects1.createFrom(runtimeScene.getObjects("hint"));
{for(var i = 0, len = gdjs._50camelCode.GDhintObjects1.length ;i < len;++i) {
    gdjs._50camelCode.GDhintObjects1[i].hide();
}
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


}; //End of gdjs._50camelCode.eventsList0xb4320


gdjs._50camelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._50camelCode.GDNewObjectObjects1.length = 0;
gdjs._50camelCode.GDNewObjectObjects2.length = 0;
gdjs._50camelCode.GDguide2Objects1.length = 0;
gdjs._50camelCode.GDguide2Objects2.length = 0;
gdjs._50camelCode.GDguideObjects1.length = 0;
gdjs._50camelCode.GDguideObjects2.length = 0;
gdjs._50camelCode.GDNewObject2Objects1.length = 0;
gdjs._50camelCode.GDNewObject2Objects2.length = 0;
gdjs._50camelCode.GDguy1Objects1.length = 0;
gdjs._50camelCode.GDguy1Objects2.length = 0;
gdjs._50camelCode.GDguy2Objects1.length = 0;
gdjs._50camelCode.GDguy2Objects2.length = 0;
gdjs._50camelCode.GDcamel2Objects1.length = 0;
gdjs._50camelCode.GDcamel2Objects2.length = 0;
gdjs._50camelCode.GDcamelObjects1.length = 0;
gdjs._50camelCode.GDcamelObjects2.length = 0;
gdjs._50camelCode.GDcamel3Objects1.length = 0;
gdjs._50camelCode.GDcamel3Objects2.length = 0;
gdjs._50camelCode.GDcamel4Objects1.length = 0;
gdjs._50camelCode.GDcamel4Objects2.length = 0;
gdjs._50camelCode.GDcamel5Objects1.length = 0;
gdjs._50camelCode.GDcamel5Objects2.length = 0;
gdjs._50camelCode.GDcamel6Objects1.length = 0;
gdjs._50camelCode.GDcamel6Objects2.length = 0;
gdjs._50camelCode.GDcamel7Objects1.length = 0;
gdjs._50camelCode.GDcamel7Objects2.length = 0;
gdjs._50camelCode.GDcamel8Objects1.length = 0;
gdjs._50camelCode.GDcamel8Objects2.length = 0;
gdjs._50camelCode.GDtownObjects1.length = 0;
gdjs._50camelCode.GDtownObjects2.length = 0;
gdjs._50camelCode.GDnext2Objects1.length = 0;
gdjs._50camelCode.GDnext2Objects2.length = 0;
gdjs._50camelCode.GDnext3Objects1.length = 0;
gdjs._50camelCode.GDnext3Objects2.length = 0;
gdjs._50camelCode.GDnext4Objects1.length = 0;
gdjs._50camelCode.GDnext4Objects2.length = 0;
gdjs._50camelCode.GDnextObjects1.length = 0;
gdjs._50camelCode.GDnextObjects2.length = 0;
gdjs._50camelCode.GDNewObject3Objects1.length = 0;
gdjs._50camelCode.GDNewObject3Objects2.length = 0;
gdjs._50camelCode.GDhintObjects1.length = 0;
gdjs._50camelCode.GDhintObjects2.length = 0;

gdjs._50camelCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['_50camelCode'] = gdjs._50camelCode;
