gdjs._49LightBulbCode = {};
gdjs._49LightBulbCode.GDbackgroundObjects1= [];
gdjs._49LightBulbCode.GDbackgroundObjects2= [];
gdjs._49LightBulbCode.GDBackObjects1= [];
gdjs._49LightBulbCode.GDBackObjects2= [];

gdjs._49LightBulbCode.conditionTrue_0 = {val:false};
gdjs._49LightBulbCode.condition0IsTrue_0 = {val:false};
gdjs._49LightBulbCode.condition1IsTrue_0 = {val:false};
gdjs._49LightBulbCode.condition2IsTrue_0 = {val:false};


gdjs._49LightBulbCode.mapOfGDgdjs_46_9549LightBulbCode_46GDBackObjects1Objects = Hashtable.newFrom({"Back": gdjs._49LightBulbCode.GDBackObjects1});gdjs._49LightBulbCode.eventsList0xb4320 = function(runtimeScene) {

{


gdjs._49LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._49LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49LightBulbCode.condition0IsTrue_0.val) {
{gdjs.adMob.loadBanner("ca-app-pub-6927019777720724/2829692216", "", true, true, true, false);
}}

}


{

gdjs._49LightBulbCode.GDBackObjects1.createFrom(runtimeScene.getObjects("Back"));

gdjs._49LightBulbCode.condition0IsTrue_0.val = false;
gdjs._49LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._49LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49LightBulbCode.mapOfGDgdjs_46_9549LightBulbCode_46GDBackObjects1Objects, runtimeScene, true, false);
}if ( gdjs._49LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._49LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._49LightBulbCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "0LightBulb", false);
}}

}


{


gdjs._49LightBulbCode.condition0IsTrue_0.val = false;
gdjs._49LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._49LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._49LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._49LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "1");
}}
if (gdjs._49LightBulbCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio\\Click-SoundBible.com-1387633738.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "1");
}}

}


{


gdjs._49LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._49LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 2);
}if (gdjs._49LightBulbCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


{


gdjs._49LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._49LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1);
}if (gdjs._49LightBulbCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Photon.mp3", 2, false, 100, 1);
}}

}


}; //End of gdjs._49LightBulbCode.eventsList0xb4320


gdjs._49LightBulbCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._49LightBulbCode.GDbackgroundObjects1.length = 0;
gdjs._49LightBulbCode.GDbackgroundObjects2.length = 0;
gdjs._49LightBulbCode.GDBackObjects1.length = 0;
gdjs._49LightBulbCode.GDBackObjects2.length = 0;

gdjs._49LightBulbCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['_49LightBulbCode'] = gdjs._49LightBulbCode;
