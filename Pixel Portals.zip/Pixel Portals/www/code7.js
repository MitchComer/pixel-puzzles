gdjs._49camelCode = {};
gdjs._49camelCode.GDdesertObjects1= [];
gdjs._49camelCode.GDdesertObjects2= [];
gdjs._49camelCode.GDguide2Objects1= [];
gdjs._49camelCode.GDguide2Objects2= [];
gdjs._49camelCode.GDguideObjects1= [];
gdjs._49camelCode.GDguideObjects2= [];
gdjs._49camelCode.GDbarObjects1= [];
gdjs._49camelCode.GDbarObjects2= [];
gdjs._49camelCode.GDnext2Objects1= [];
gdjs._49camelCode.GDnext2Objects2= [];
gdjs._49camelCode.GDnextObjects1= [];
gdjs._49camelCode.GDnextObjects2= [];
gdjs._49camelCode.GDBack2Objects1= [];
gdjs._49camelCode.GDBack2Objects2= [];
gdjs._49camelCode.GDBackObjects1= [];
gdjs._49camelCode.GDBackObjects2= [];

gdjs._49camelCode.conditionTrue_0 = {val:false};
gdjs._49camelCode.condition0IsTrue_0 = {val:false};
gdjs._49camelCode.condition1IsTrue_0 = {val:false};
gdjs._49camelCode.condition2IsTrue_0 = {val:false};


gdjs._49camelCode.mapOfGDgdjs_46_9549camelCode_46GDnext2Objects1Objects = Hashtable.newFrom({"next2": gdjs._49camelCode.GDnext2Objects1});gdjs._49camelCode.mapOfGDgdjs_46_9549camelCode_46GDBack2Objects1Objects = Hashtable.newFrom({"Back2": gdjs._49camelCode.GDBack2Objects1});gdjs._49camelCode.eventsList0xb4320 = function(runtimeScene) {

{


gdjs._49camelCode.condition0IsTrue_0.val = false;
{
gdjs._49camelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49camelCode.condition0IsTrue_0.val) {
{gdjs.adMob.loadBanner("ca-app-pub-6927019777720724/2829692216", "", true, true, true, false);
}}

}


{

gdjs._49camelCode.GDnext2Objects1.createFrom(runtimeScene.getObjects("next2"));

gdjs._49camelCode.condition0IsTrue_0.val = false;
gdjs._49camelCode.condition1IsTrue_0.val = false;
{
gdjs._49camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49camelCode.mapOfGDgdjs_46_9549camelCode_46GDnext2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._49camelCode.condition0IsTrue_0.val ) {
{
gdjs._49camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._49camelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "2camel", false);
}}

}


{


gdjs._49camelCode.condition0IsTrue_0.val = false;
gdjs._49camelCode.condition1IsTrue_0.val = false;
{
gdjs._49camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._49camelCode.condition0IsTrue_0.val ) {
{
gdjs._49camelCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "1");
}}
if (gdjs._49camelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio\\Click-SoundBible.com-1387633738.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "1");
}}

}


{


gdjs._49camelCode.condition0IsTrue_0.val = false;
{
gdjs._49camelCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 2);
}if (gdjs._49camelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


{


gdjs._49camelCode.condition0IsTrue_0.val = false;
{
gdjs._49camelCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1);
}if (gdjs._49camelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Photon.mp3", 2, false, 100, 1);
}}

}


{

gdjs._49camelCode.GDBack2Objects1.createFrom(runtimeScene.getObjects("Back2"));

gdjs._49camelCode.condition0IsTrue_0.val = false;
gdjs._49camelCode.condition1IsTrue_0.val = false;
{
gdjs._49camelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._49camelCode.mapOfGDgdjs_46_9549camelCode_46GDBack2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._49camelCode.condition0IsTrue_0.val ) {
{
gdjs._49camelCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._49camelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "0camel", false);
}}

}


}; //End of gdjs._49camelCode.eventsList0xb4320


gdjs._49camelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._49camelCode.GDdesertObjects1.length = 0;
gdjs._49camelCode.GDdesertObjects2.length = 0;
gdjs._49camelCode.GDguide2Objects1.length = 0;
gdjs._49camelCode.GDguide2Objects2.length = 0;
gdjs._49camelCode.GDguideObjects1.length = 0;
gdjs._49camelCode.GDguideObjects2.length = 0;
gdjs._49camelCode.GDbarObjects1.length = 0;
gdjs._49camelCode.GDbarObjects2.length = 0;
gdjs._49camelCode.GDnext2Objects1.length = 0;
gdjs._49camelCode.GDnext2Objects2.length = 0;
gdjs._49camelCode.GDnextObjects1.length = 0;
gdjs._49camelCode.GDnextObjects2.length = 0;
gdjs._49camelCode.GDBack2Objects1.length = 0;
gdjs._49camelCode.GDBack2Objects2.length = 0;
gdjs._49camelCode.GDBackObjects1.length = 0;
gdjs._49camelCode.GDBackObjects2.length = 0;

gdjs._49camelCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['_49camelCode'] = gdjs._49camelCode;
