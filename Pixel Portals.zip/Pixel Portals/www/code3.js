gdjs._50LightBulbCode = {};
gdjs._50LightBulbCode.GDbackgroundObjects1= [];
gdjs._50LightBulbCode.GDbackgroundObjects2= [];
gdjs._50LightBulbCode.GDBackObjects1= [];
gdjs._50LightBulbCode.GDBackObjects2= [];

gdjs._50LightBulbCode.conditionTrue_0 = {val:false};
gdjs._50LightBulbCode.condition0IsTrue_0 = {val:false};
gdjs._50LightBulbCode.condition1IsTrue_0 = {val:false};
gdjs._50LightBulbCode.condition2IsTrue_0 = {val:false};


gdjs._50LightBulbCode.mapOfGDgdjs_46_9550LightBulbCode_46GDBackObjects1Objects = Hashtable.newFrom({"Back": gdjs._50LightBulbCode.GDBackObjects1});gdjs._50LightBulbCode.eventsList0xb4320 = function(runtimeScene) {

{

gdjs._50LightBulbCode.GDBackObjects1.createFrom(runtimeScene.getObjects("Back"));

gdjs._50LightBulbCode.condition0IsTrue_0.val = false;
gdjs._50LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._50LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._50LightBulbCode.mapOfGDgdjs_46_9550LightBulbCode_46GDBackObjects1Objects, runtimeScene, true, false);
}if ( gdjs._50LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._50LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._50LightBulbCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "0LightBulb", false);
}}

}


{


gdjs._50LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._50LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._50LightBulbCode.condition0IsTrue_0.val) {
{gdjs.adMob.loadBanner("ca-app-pub-6927019777720724/2829692216", "", true, true, true, false);
}}

}


{


gdjs._50LightBulbCode.condition0IsTrue_0.val = false;
gdjs._50LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._50LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._50LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._50LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "1");
}}
if (gdjs._50LightBulbCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio\\Click-SoundBible.com-1387633738.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "1");
}}

}


{


gdjs._50LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._50LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 2);
}if (gdjs._50LightBulbCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


{


gdjs._50LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._50LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1);
}if (gdjs._50LightBulbCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Photon.mp3", 2, false, 100, 1);
}}

}


{


{
}

}


}; //End of gdjs._50LightBulbCode.eventsList0xb4320


gdjs._50LightBulbCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._50LightBulbCode.GDbackgroundObjects1.length = 0;
gdjs._50LightBulbCode.GDbackgroundObjects2.length = 0;
gdjs._50LightBulbCode.GDBackObjects1.length = 0;
gdjs._50LightBulbCode.GDBackObjects2.length = 0;

gdjs._50LightBulbCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['_50LightBulbCode'] = gdjs._50LightBulbCode;
