gdjs._51LightBulbCode = {};
gdjs._51LightBulbCode.GDbackgroundObjects1= [];
gdjs._51LightBulbCode.GDbackgroundObjects2= [];
gdjs._51LightBulbCode.GDNextObjects1= [];
gdjs._51LightBulbCode.GDNextObjects2= [];

gdjs._51LightBulbCode.conditionTrue_0 = {val:false};
gdjs._51LightBulbCode.condition0IsTrue_0 = {val:false};
gdjs._51LightBulbCode.condition1IsTrue_0 = {val:false};
gdjs._51LightBulbCode.condition2IsTrue_0 = {val:false};


gdjs._51LightBulbCode.mapOfGDgdjs_46_9551LightBulbCode_46GDNextObjects1Objects = Hashtable.newFrom({"Next": gdjs._51LightBulbCode.GDNextObjects1});gdjs._51LightBulbCode.eventsList0xb4320 = function(runtimeScene) {

{



}


{


gdjs._51LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._51LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._51LightBulbCode.condition0IsTrue_0.val) {
{gdjs.adMob.loadBanner("ca-app-pub-6927019777720724/2829692216", "", true, true, true, false);
}}

}


{


gdjs._51LightBulbCode.condition0IsTrue_0.val = false;
gdjs._51LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._51LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._51LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._51LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "1");
}}
if (gdjs._51LightBulbCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio\\Click-SoundBible.com-1387633738.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "1");
}}

}


{


gdjs._51LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._51LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 2);
}if (gdjs._51LightBulbCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


{


gdjs._51LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._51LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1);
}if (gdjs._51LightBulbCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Photon.mp3", 2, false, 100, 1);
}}

}


{

gdjs._51LightBulbCode.GDNextObjects1.createFrom(runtimeScene.getObjects("Next"));

gdjs._51LightBulbCode.condition0IsTrue_0.val = false;
gdjs._51LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._51LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._51LightBulbCode.mapOfGDgdjs_46_9551LightBulbCode_46GDNextObjects1Objects, runtimeScene, true, false);
}if ( gdjs._51LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._51LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._51LightBulbCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "0pingpong", false);
}}

}


}; //End of gdjs._51LightBulbCode.eventsList0xb4320


gdjs._51LightBulbCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._51LightBulbCode.GDbackgroundObjects1.length = 0;
gdjs._51LightBulbCode.GDbackgroundObjects2.length = 0;
gdjs._51LightBulbCode.GDNextObjects1.length = 0;
gdjs._51LightBulbCode.GDNextObjects2.length = 0;

gdjs._51LightBulbCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['_51LightBulbCode'] = gdjs._51LightBulbCode;
