gdjs._48LightBulbCode = {};
gdjs._48LightBulbCode.GDswitchObjects1= [];
gdjs._48LightBulbCode.GDswitchObjects2= [];
gdjs._48LightBulbCode.GDunlitObjects1= [];
gdjs._48LightBulbCode.GDunlitObjects2= [];
gdjs._48LightBulbCode.GDwaslitObjects1= [];
gdjs._48LightBulbCode.GDwaslitObjects2= [];
gdjs._48LightBulbCode.GDlitObjects1= [];
gdjs._48LightBulbCode.GDlitObjects2= [];
gdjs._48LightBulbCode.GDcheck4Objects1= [];
gdjs._48LightBulbCode.GDcheck4Objects2= [];
gdjs._48LightBulbCode.GDcheck3Objects1= [];
gdjs._48LightBulbCode.GDcheck3Objects2= [];
gdjs._48LightBulbCode.GDcheck2Objects1= [];
gdjs._48LightBulbCode.GDcheck2Objects2= [];
gdjs._48LightBulbCode.GDcheckAObjects1= [];
gdjs._48LightBulbCode.GDcheckAObjects2= [];
gdjs._48LightBulbCode.GDcheckBObjects1= [];
gdjs._48LightBulbCode.GDcheckBObjects2= [];
gdjs._48LightBulbCode.GDcheckObjects1= [];
gdjs._48LightBulbCode.GDcheckObjects2= [];
gdjs._48LightBulbCode.GDflip1Objects1= [];
gdjs._48LightBulbCode.GDflip1Objects2= [];
gdjs._48LightBulbCode.GDflip2Objects1= [];
gdjs._48LightBulbCode.GDflip2Objects2= [];
gdjs._48LightBulbCode.GDflip3Objects1= [];
gdjs._48LightBulbCode.GDflip3Objects2= [];
gdjs._48LightBulbCode.GDflip4Objects1= [];
gdjs._48LightBulbCode.GDflip4Objects2= [];
gdjs._48LightBulbCode.GDflip1litObjects1= [];
gdjs._48LightBulbCode.GDflip1litObjects2= [];
gdjs._48LightBulbCode.GDflip2litObjects1= [];
gdjs._48LightBulbCode.GDflip2litObjects2= [];
gdjs._48LightBulbCode.GDflip3litObjects1= [];
gdjs._48LightBulbCode.GDflip3litObjects2= [];
gdjs._48LightBulbCode.GDflip4litObjects1= [];
gdjs._48LightBulbCode.GDflip4litObjects2= [];
gdjs._48LightBulbCode.GDCHEATObjects1= [];
gdjs._48LightBulbCode.GDCHEATObjects2= [];
gdjs._48LightBulbCode.GDCHEAT2Objects1= [];
gdjs._48LightBulbCode.GDCHEAT2Objects2= [];
gdjs._48LightBulbCode.GDCHEAT3Objects1= [];
gdjs._48LightBulbCode.GDCHEAT3Objects2= [];
gdjs._48LightBulbCode.GDCHEAT4Objects1= [];
gdjs._48LightBulbCode.GDCHEAT4Objects2= [];
gdjs._48LightBulbCode.GDGuide2Objects1= [];
gdjs._48LightBulbCode.GDGuide2Objects2= [];
gdjs._48LightBulbCode.GDGuideObjects1= [];
gdjs._48LightBulbCode.GDGuideObjects2= [];
gdjs._48LightBulbCode.GDbarObjects1= [];
gdjs._48LightBulbCode.GDbarObjects2= [];
gdjs._48LightBulbCode.GDicon2Objects1= [];
gdjs._48LightBulbCode.GDicon2Objects2= [];
gdjs._48LightBulbCode.GDiconObjects1= [];
gdjs._48LightBulbCode.GDiconObjects2= [];
gdjs._48LightBulbCode.GDNewObjectObjects1= [];
gdjs._48LightBulbCode.GDNewObjectObjects2= [];
gdjs._48LightBulbCode.GDhintObjects1= [];
gdjs._48LightBulbCode.GDhintObjects2= [];

gdjs._48LightBulbCode.conditionTrue_0 = {val:false};
gdjs._48LightBulbCode.condition0IsTrue_0 = {val:false};
gdjs._48LightBulbCode.condition1IsTrue_0 = {val:false};
gdjs._48LightBulbCode.condition2IsTrue_0 = {val:false};
gdjs._48LightBulbCode.condition3IsTrue_0 = {val:false};


gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDiconObjects1Objects = Hashtable.newFrom({"icon": gdjs._48LightBulbCode.GDiconObjects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDicon2Objects1Objects = Hashtable.newFrom({"icon2": gdjs._48LightBulbCode.GDicon2Objects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip2Objects1Objects = Hashtable.newFrom({"flip2": gdjs._48LightBulbCode.GDflip2Objects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip2litObjects1Objects = Hashtable.newFrom({"flip2lit": gdjs._48LightBulbCode.GDflip2litObjects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDcheck2Objects1Objects = Hashtable.newFrom({"check2": gdjs._48LightBulbCode.GDcheck2Objects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip4Objects1Objects = Hashtable.newFrom({"flip4": gdjs._48LightBulbCode.GDflip4Objects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip4litObjects1Objects = Hashtable.newFrom({"flip4lit": gdjs._48LightBulbCode.GDflip4litObjects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDcheck4Objects1Objects = Hashtable.newFrom({"check4": gdjs._48LightBulbCode.GDcheck4Objects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip3Objects1Objects = Hashtable.newFrom({"flip3": gdjs._48LightBulbCode.GDflip3Objects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip3litObjects1Objects = Hashtable.newFrom({"flip3lit": gdjs._48LightBulbCode.GDflip3litObjects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDcheck3Objects1Objects = Hashtable.newFrom({"check3": gdjs._48LightBulbCode.GDcheck3Objects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip1Objects1Objects = Hashtable.newFrom({"flip1": gdjs._48LightBulbCode.GDflip1Objects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip1litObjects1Objects = Hashtable.newFrom({"flip1lit": gdjs._48LightBulbCode.GDflip1litObjects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDcheckBObjects1Objects = Hashtable.newFrom({"checkB": gdjs._48LightBulbCode.GDcheckBObjects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDcheckObjects1Objects = Hashtable.newFrom({"check": gdjs._48LightBulbCode.GDcheckObjects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDcheckAObjects1Objects = Hashtable.newFrom({"checkA": gdjs._48LightBulbCode.GDcheckAObjects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDCHEATObjects1Objects = Hashtable.newFrom({"CHEAT": gdjs._48LightBulbCode.GDCHEATObjects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDCHEAT2Objects1Objects = Hashtable.newFrom({"CHEAT2": gdjs._48LightBulbCode.GDCHEAT2Objects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDCHEAT3Objects1Objects = Hashtable.newFrom({"CHEAT3": gdjs._48LightBulbCode.GDCHEAT3Objects1});gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDCHEAT4Objects1Objects = Hashtable.newFrom({"CHEAT4": gdjs._48LightBulbCode.GDCHEAT4Objects1});gdjs._48LightBulbCode.eventsList0xb4320 = function(runtimeScene) {

{



}


{


gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 60, "60");
}if (gdjs._48LightBulbCode.condition0IsTrue_0.val) {
gdjs._48LightBulbCode.GDhintObjects1.createFrom(runtimeScene.getObjects("hint"));
{for(var i = 0, len = gdjs._48LightBulbCode.GDhintObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDhintObjects1[i].hide(false);
}
}}

}


{


gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._48LightBulbCode.condition0IsTrue_0.val) {
gdjs._48LightBulbCode.GDhintObjects1.createFrom(runtimeScene.getObjects("hint"));
{for(var i = 0, len = gdjs._48LightBulbCode.GDhintObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDhintObjects1[i].hide();
}
}}

}


{


gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._48LightBulbCode.condition0IsTrue_0.val) {
gdjs._48LightBulbCode.GDCHEAT2Objects1.createFrom(runtimeScene.getObjects("CHEAT2"));
gdjs._48LightBulbCode.GDCHEAT3Objects1.createFrom(runtimeScene.getObjects("CHEAT3"));
gdjs._48LightBulbCode.GDCHEAT4Objects1.createFrom(runtimeScene.getObjects("CHEAT4"));
gdjs._48LightBulbCode.GDGuideObjects1.createFrom(runtimeScene.getObjects("Guide"));
gdjs._48LightBulbCode.GDGuide2Objects1.createFrom(runtimeScene.getObjects("Guide2"));
gdjs._48LightBulbCode.GDbarObjects1.createFrom(runtimeScene.getObjects("bar"));
gdjs._48LightBulbCode.GDcheckObjects1.createFrom(runtimeScene.getObjects("check"));
gdjs._48LightBulbCode.GDcheck2Objects1.createFrom(runtimeScene.getObjects("check2"));
gdjs._48LightBulbCode.GDcheck3Objects1.createFrom(runtimeScene.getObjects("check3"));
gdjs._48LightBulbCode.GDcheck4Objects1.createFrom(runtimeScene.getObjects("check4"));
gdjs._48LightBulbCode.GDcheckAObjects1.createFrom(runtimeScene.getObjects("checkA"));
gdjs._48LightBulbCode.GDcheckBObjects1.createFrom(runtimeScene.getObjects("checkB"));
gdjs._48LightBulbCode.GDicon2Objects1.createFrom(runtimeScene.getObjects("icon2"));
{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck3Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck4Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckAObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckAObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckBObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckBObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDCHEAT2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDCHEAT2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDCHEAT3Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDCHEAT3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDCHEAT4Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDCHEAT4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDbarObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDbarObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDicon2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDicon2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDGuideObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDGuideObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDGuide2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDGuide2Objects1[i].hide();
}
}{gdjs.adMob.loadBanner("ca-app-pub-6927019777720724/2829692216", "", true, true, true, false);
}}

}


{

gdjs._48LightBulbCode.GDiconObjects1.createFrom(runtimeScene.getObjects("icon"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDiconObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
gdjs._48LightBulbCode.GDGuideObjects1.createFrom(runtimeScene.getObjects("Guide"));
gdjs._48LightBulbCode.GDGuide2Objects1.createFrom(runtimeScene.getObjects("Guide2"));
gdjs._48LightBulbCode.GDbarObjects1.createFrom(runtimeScene.getObjects("bar"));
/* Reuse gdjs._48LightBulbCode.GDiconObjects1 */
gdjs._48LightBulbCode.GDicon2Objects1.createFrom(runtimeScene.getObjects("icon2"));
{for(var i = 0, len = gdjs._48LightBulbCode.GDicon2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDicon2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDbarObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDbarObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDiconObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDiconObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDGuideObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDGuideObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDGuide2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDGuide2Objects1[i].hide(false);
}
}}

}


{

gdjs._48LightBulbCode.GDicon2Objects1.createFrom(runtimeScene.getObjects("icon2"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDicon2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
gdjs._48LightBulbCode.GDGuideObjects1.createFrom(runtimeScene.getObjects("Guide"));
gdjs._48LightBulbCode.GDGuide2Objects1.createFrom(runtimeScene.getObjects("Guide2"));
gdjs._48LightBulbCode.GDbarObjects1.createFrom(runtimeScene.getObjects("bar"));
gdjs._48LightBulbCode.GDiconObjects1.createFrom(runtimeScene.getObjects("icon"));
/* Reuse gdjs._48LightBulbCode.GDicon2Objects1 */
{for(var i = 0, len = gdjs._48LightBulbCode.GDicon2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDicon2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDbarObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDbarObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDiconObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDiconObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDGuideObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDGuideObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDGuide2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDGuide2Objects1[i].hide();
}
}}

}


{

gdjs._48LightBulbCode.GDflip2Objects1.createFrom(runtimeScene.getObjects("flip2"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
gdjs._48LightBulbCode.GDcheckObjects1.createFrom(runtimeScene.getObjects("check"));
gdjs._48LightBulbCode.GDcheck2Objects1.createFrom(runtimeScene.getObjects("check2"));
gdjs._48LightBulbCode.GDcheck3Objects1.createFrom(runtimeScene.getObjects("check3"));
gdjs._48LightBulbCode.GDcheck4Objects1.createFrom(runtimeScene.getObjects("check4"));
gdjs._48LightBulbCode.GDcheckAObjects1.createFrom(runtimeScene.getObjects("checkA"));
gdjs._48LightBulbCode.GDcheckBObjects1.createFrom(runtimeScene.getObjects("checkB"));
gdjs._48LightBulbCode.GDflip1litObjects1.createFrom(runtimeScene.getObjects("flip1lit"));
gdjs._48LightBulbCode.GDflip3litObjects1.createFrom(runtimeScene.getObjects("flip3lit"));
gdjs._48LightBulbCode.GDflip4litObjects1.createFrom(runtimeScene.getObjects("flip4lit"));
gdjs._48LightBulbCode.GDflip2litObjects1.length = 0;

{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck2Objects1[i].hide(false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip2litObjects1Objects, 221, 922, "Layer");
}{for(var i = 0, len = gdjs._48LightBulbCode.GDflip1litObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDflip1litObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDflip3litObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDflip3litObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDflip4litObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDflip4litObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck3Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckAObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckAObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck4Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckBObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckBObjects1[i].hide();
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "check");
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "checkA");
}}

}


{

gdjs._48LightBulbCode.GDcheck2Objects1.createFrom(runtimeScene.getObjects("check2"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
gdjs._48LightBulbCode.condition2IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDcheck2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._48LightBulbCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._48LightBulbCode.GDcheck2Objects1.length;i<l;++i) {
    if ( gdjs._48LightBulbCode.GDcheck2Objects1[i].isVisible() ) {
        gdjs._48LightBulbCode.condition2IsTrue_0.val = true;
        gdjs._48LightBulbCode.GDcheck2Objects1[k] = gdjs._48LightBulbCode.GDcheck2Objects1[i];
        ++k;
    }
}
gdjs._48LightBulbCode.GDcheck2Objects1.length = k;}}
}
if (gdjs._48LightBulbCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1LightBulb", false);
}}

}


{

gdjs._48LightBulbCode.GDflip4Objects1.createFrom(runtimeScene.getObjects("flip4"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip4Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
gdjs._48LightBulbCode.GDcheckObjects1.createFrom(runtimeScene.getObjects("check"));
gdjs._48LightBulbCode.GDcheck2Objects1.createFrom(runtimeScene.getObjects("check2"));
gdjs._48LightBulbCode.GDcheck3Objects1.createFrom(runtimeScene.getObjects("check3"));
gdjs._48LightBulbCode.GDcheck4Objects1.createFrom(runtimeScene.getObjects("check4"));
gdjs._48LightBulbCode.GDcheckAObjects1.createFrom(runtimeScene.getObjects("checkA"));
gdjs._48LightBulbCode.GDcheckBObjects1.createFrom(runtimeScene.getObjects("checkB"));
gdjs._48LightBulbCode.GDflip1litObjects1.createFrom(runtimeScene.getObjects("flip1lit"));
gdjs._48LightBulbCode.GDflip2litObjects1.createFrom(runtimeScene.getObjects("flip2lit"));
gdjs._48LightBulbCode.GDflip3litObjects1.createFrom(runtimeScene.getObjects("flip3lit"));
gdjs._48LightBulbCode.GDflip4litObjects1.length = 0;

{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck4Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck4Objects1[i].hide(false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip4litObjects1Objects, 563, 922, "Layer");
}{for(var i = 0, len = gdjs._48LightBulbCode.GDflip3litObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDflip3litObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDflip1litObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDflip1litObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDflip2litObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDflip2litObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck3Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckAObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckAObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckBObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckBObjects1[i].hide();
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "check");
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "checkA");
}}

}


{

gdjs._48LightBulbCode.GDcheck4Objects1.createFrom(runtimeScene.getObjects("check4"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
gdjs._48LightBulbCode.condition2IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDcheck4Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._48LightBulbCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._48LightBulbCode.GDcheck4Objects1.length;i<l;++i) {
    if ( gdjs._48LightBulbCode.GDcheck4Objects1[i].isVisible() ) {
        gdjs._48LightBulbCode.condition2IsTrue_0.val = true;
        gdjs._48LightBulbCode.GDcheck4Objects1[k] = gdjs._48LightBulbCode.GDcheck4Objects1[i];
        ++k;
    }
}
gdjs._48LightBulbCode.GDcheck4Objects1.length = k;}}
}
if (gdjs._48LightBulbCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1LightBulb", false);
}}

}


{

gdjs._48LightBulbCode.GDflip3Objects1.createFrom(runtimeScene.getObjects("flip3"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip3Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
gdjs._48LightBulbCode.GDcheckObjects1.createFrom(runtimeScene.getObjects("check"));
gdjs._48LightBulbCode.GDcheck2Objects1.createFrom(runtimeScene.getObjects("check2"));
gdjs._48LightBulbCode.GDcheck3Objects1.createFrom(runtimeScene.getObjects("check3"));
gdjs._48LightBulbCode.GDcheck4Objects1.createFrom(runtimeScene.getObjects("check4"));
gdjs._48LightBulbCode.GDcheckAObjects1.createFrom(runtimeScene.getObjects("checkA"));
gdjs._48LightBulbCode.GDcheckBObjects1.createFrom(runtimeScene.getObjects("checkB"));
gdjs._48LightBulbCode.GDflip1litObjects1.createFrom(runtimeScene.getObjects("flip1lit"));
gdjs._48LightBulbCode.GDflip2litObjects1.createFrom(runtimeScene.getObjects("flip2lit"));
gdjs._48LightBulbCode.GDflip4litObjects1.createFrom(runtimeScene.getObjects("flip4lit"));
gdjs._48LightBulbCode.GDflip3litObjects1.length = 0;

{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck3Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck3Objects1[i].hide(false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip3litObjects1Objects, 344, 922, "Layer");
}{for(var i = 0, len = gdjs._48LightBulbCode.GDflip2litObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDflip2litObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDflip1litObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDflip1litObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDflip4litObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDflip4litObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckAObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckAObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck4Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckBObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckBObjects1[i].hide();
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "check");
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "checkA");
}}

}


{

gdjs._48LightBulbCode.GDcheck3Objects1.createFrom(runtimeScene.getObjects("check3"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
gdjs._48LightBulbCode.condition2IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDcheck3Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._48LightBulbCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._48LightBulbCode.GDcheck3Objects1.length;i<l;++i) {
    if ( gdjs._48LightBulbCode.GDcheck3Objects1[i].isVisible() ) {
        gdjs._48LightBulbCode.condition2IsTrue_0.val = true;
        gdjs._48LightBulbCode.GDcheck3Objects1[k] = gdjs._48LightBulbCode.GDcheck3Objects1[i];
        ++k;
    }
}
gdjs._48LightBulbCode.GDcheck3Objects1.length = k;}}
}
if (gdjs._48LightBulbCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1LightBulb", false);
}}

}


{



}


{

gdjs._48LightBulbCode.GDflip1Objects1.createFrom(runtimeScene.getObjects("flip1"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip1Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
gdjs._48LightBulbCode.GDcheck2Objects1.createFrom(runtimeScene.getObjects("check2"));
gdjs._48LightBulbCode.GDcheck3Objects1.createFrom(runtimeScene.getObjects("check3"));
gdjs._48LightBulbCode.GDcheck4Objects1.createFrom(runtimeScene.getObjects("check4"));
gdjs._48LightBulbCode.GDcheckBObjects1.createFrom(runtimeScene.getObjects("checkB"));
gdjs._48LightBulbCode.GDflip2litObjects1.createFrom(runtimeScene.getObjects("flip2lit"));
gdjs._48LightBulbCode.GDflip3litObjects1.createFrom(runtimeScene.getObjects("flip3lit"));
gdjs._48LightBulbCode.GDflip4litObjects1.createFrom(runtimeScene.getObjects("flip4lit"));
gdjs._48LightBulbCode.GDflip1litObjects1.length = 0;

{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckBObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckBObjects1[i].hide(false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDflip1litObjects1Objects, 95, 922, "Layer");
}{for(var i = 0, len = gdjs._48LightBulbCode.GDflip3litObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDflip3litObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDflip2litObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDflip2litObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDflip4litObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDflip4litObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck3Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheck4Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheck4Objects1[i].hide();
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "checkA");
}}

}


{



}


{

gdjs._48LightBulbCode.GDcheckBObjects1.createFrom(runtimeScene.getObjects("checkB"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48LightBulbCode.GDcheckBObjects1.length;i<l;++i) {
    if ( gdjs._48LightBulbCode.GDcheckBObjects1[i].isVisible() ) {
        gdjs._48LightBulbCode.condition0IsTrue_0.val = true;
        gdjs._48LightBulbCode.GDcheckBObjects1[k] = gdjs._48LightBulbCode.GDcheckBObjects1[i];
        ++k;
    }
}
gdjs._48LightBulbCode.GDcheckBObjects1.length = k;}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 10, "check");
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
gdjs._48LightBulbCode.GDcheckObjects1.createFrom(runtimeScene.getObjects("check"));
/* Reuse gdjs._48LightBulbCode.GDcheckBObjects1 */
{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckBObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckBObjects1[i].hide();
}
}}

}


{



}


{

gdjs._48LightBulbCode.GDcheckObjects1.createFrom(runtimeScene.getObjects("check"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48LightBulbCode.GDcheckObjects1.length;i<l;++i) {
    if ( gdjs._48LightBulbCode.GDcheckObjects1[i].isVisible() ) {
        gdjs._48LightBulbCode.condition0IsTrue_0.val = true;
        gdjs._48LightBulbCode.GDcheckObjects1[k] = gdjs._48LightBulbCode.GDcheckObjects1[i];
        ++k;
    }
}
gdjs._48LightBulbCode.GDcheckObjects1.length = k;}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 10, "checkA");
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
/* Reuse gdjs._48LightBulbCode.GDcheckObjects1 */
gdjs._48LightBulbCode.GDcheckAObjects1.createFrom(runtimeScene.getObjects("checkA"));
{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckAObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckAObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48LightBulbCode.GDcheckObjects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDcheckObjects1[i].hide();
}
}}

}


{

gdjs._48LightBulbCode.GDcheckBObjects1.createFrom(runtimeScene.getObjects("checkB"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDcheckBObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1LightBulb", false);
}}

}


{

gdjs._48LightBulbCode.GDcheckObjects1.createFrom(runtimeScene.getObjects("check"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDcheckObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "2LightBulb", false);
}}

}


{



}


{

gdjs._48LightBulbCode.GDcheckAObjects1.createFrom(runtimeScene.getObjects("checkA"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
gdjs._48LightBulbCode.condition2IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDcheckAObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._48LightBulbCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._48LightBulbCode.GDcheckAObjects1.length;i<l;++i) {
    if ( gdjs._48LightBulbCode.GDcheckAObjects1[i].isVisible() ) {
        gdjs._48LightBulbCode.condition2IsTrue_0.val = true;
        gdjs._48LightBulbCode.GDcheckAObjects1[k] = gdjs._48LightBulbCode.GDcheckAObjects1[i];
        ++k;
    }
}
gdjs._48LightBulbCode.GDcheckAObjects1.length = k;}}
}
if (gdjs._48LightBulbCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "3LightBulb", false);
}}

}


{



}


{

gdjs._48LightBulbCode.GDCHEATObjects1.createFrom(runtimeScene.getObjects("CHEAT"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDCHEATObjects1Objects, runtimeScene, true, false);
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
gdjs._48LightBulbCode.GDCHEAT2Objects1.createFrom(runtimeScene.getObjects("CHEAT2"));
{for(var i = 0, len = gdjs._48LightBulbCode.GDCHEAT2Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDCHEAT2Objects1[i].hide(false);
}
}}

}


{

gdjs._48LightBulbCode.GDCHEAT2Objects1.createFrom(runtimeScene.getObjects("CHEAT2"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDCHEAT2Objects1Objects, runtimeScene, true, false);
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
gdjs._48LightBulbCode.GDCHEAT3Objects1.createFrom(runtimeScene.getObjects("CHEAT3"));
{for(var i = 0, len = gdjs._48LightBulbCode.GDCHEAT3Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDCHEAT3Objects1[i].hide(false);
}
}}

}


{

gdjs._48LightBulbCode.GDCHEAT3Objects1.createFrom(runtimeScene.getObjects("CHEAT3"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDCHEAT3Objects1Objects, runtimeScene, true, false);
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
gdjs._48LightBulbCode.GDCHEAT4Objects1.createFrom(runtimeScene.getObjects("CHEAT4"));
{for(var i = 0, len = gdjs._48LightBulbCode.GDCHEAT4Objects1.length ;i < len;++i) {
    gdjs._48LightBulbCode.GDCHEAT4Objects1[i].hide(false);
}
}}

}


{



}


{

gdjs._48LightBulbCode.GDCHEAT4Objects1.createFrom(runtimeScene.getObjects("CHEAT4"));

gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
gdjs._48LightBulbCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48LightBulbCode.GDCHEAT4Objects1.length;i<l;++i) {
    if ( gdjs._48LightBulbCode.GDCHEAT4Objects1[i].isVisible() ) {
        gdjs._48LightBulbCode.condition0IsTrue_0.val = true;
        gdjs._48LightBulbCode.GDCHEAT4Objects1[k] = gdjs._48LightBulbCode.GDCHEAT4Objects1[i];
        ++k;
    }
}
gdjs._48LightBulbCode.GDCHEAT4Objects1.length = k;}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48LightBulbCode.mapOfGDgdjs_46_9548LightBulbCode_46GDCHEAT4Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48LightBulbCode.condition1IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48LightBulbCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "gg", false);
}}

}


{


gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
gdjs._48LightBulbCode.condition1IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._48LightBulbCode.condition0IsTrue_0.val ) {
{
gdjs._48LightBulbCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "1");
}}
if (gdjs._48LightBulbCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio\\Click-SoundBible.com-1387633738.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "1");
}}

}


{


gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 2);
}if (gdjs._48LightBulbCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


{


gdjs._48LightBulbCode.condition0IsTrue_0.val = false;
{
gdjs._48LightBulbCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1);
}if (gdjs._48LightBulbCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Photon.mp3", 2, false, 100, 1);
}}

}


{


{
}

}


}; //End of gdjs._48LightBulbCode.eventsList0xb4320


gdjs._48LightBulbCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._48LightBulbCode.GDswitchObjects1.length = 0;
gdjs._48LightBulbCode.GDswitchObjects2.length = 0;
gdjs._48LightBulbCode.GDunlitObjects1.length = 0;
gdjs._48LightBulbCode.GDunlitObjects2.length = 0;
gdjs._48LightBulbCode.GDwaslitObjects1.length = 0;
gdjs._48LightBulbCode.GDwaslitObjects2.length = 0;
gdjs._48LightBulbCode.GDlitObjects1.length = 0;
gdjs._48LightBulbCode.GDlitObjects2.length = 0;
gdjs._48LightBulbCode.GDcheck4Objects1.length = 0;
gdjs._48LightBulbCode.GDcheck4Objects2.length = 0;
gdjs._48LightBulbCode.GDcheck3Objects1.length = 0;
gdjs._48LightBulbCode.GDcheck3Objects2.length = 0;
gdjs._48LightBulbCode.GDcheck2Objects1.length = 0;
gdjs._48LightBulbCode.GDcheck2Objects2.length = 0;
gdjs._48LightBulbCode.GDcheckAObjects1.length = 0;
gdjs._48LightBulbCode.GDcheckAObjects2.length = 0;
gdjs._48LightBulbCode.GDcheckBObjects1.length = 0;
gdjs._48LightBulbCode.GDcheckBObjects2.length = 0;
gdjs._48LightBulbCode.GDcheckObjects1.length = 0;
gdjs._48LightBulbCode.GDcheckObjects2.length = 0;
gdjs._48LightBulbCode.GDflip1Objects1.length = 0;
gdjs._48LightBulbCode.GDflip1Objects2.length = 0;
gdjs._48LightBulbCode.GDflip2Objects1.length = 0;
gdjs._48LightBulbCode.GDflip2Objects2.length = 0;
gdjs._48LightBulbCode.GDflip3Objects1.length = 0;
gdjs._48LightBulbCode.GDflip3Objects2.length = 0;
gdjs._48LightBulbCode.GDflip4Objects1.length = 0;
gdjs._48LightBulbCode.GDflip4Objects2.length = 0;
gdjs._48LightBulbCode.GDflip1litObjects1.length = 0;
gdjs._48LightBulbCode.GDflip1litObjects2.length = 0;
gdjs._48LightBulbCode.GDflip2litObjects1.length = 0;
gdjs._48LightBulbCode.GDflip2litObjects2.length = 0;
gdjs._48LightBulbCode.GDflip3litObjects1.length = 0;
gdjs._48LightBulbCode.GDflip3litObjects2.length = 0;
gdjs._48LightBulbCode.GDflip4litObjects1.length = 0;
gdjs._48LightBulbCode.GDflip4litObjects2.length = 0;
gdjs._48LightBulbCode.GDCHEATObjects1.length = 0;
gdjs._48LightBulbCode.GDCHEATObjects2.length = 0;
gdjs._48LightBulbCode.GDCHEAT2Objects1.length = 0;
gdjs._48LightBulbCode.GDCHEAT2Objects2.length = 0;
gdjs._48LightBulbCode.GDCHEAT3Objects1.length = 0;
gdjs._48LightBulbCode.GDCHEAT3Objects2.length = 0;
gdjs._48LightBulbCode.GDCHEAT4Objects1.length = 0;
gdjs._48LightBulbCode.GDCHEAT4Objects2.length = 0;
gdjs._48LightBulbCode.GDGuide2Objects1.length = 0;
gdjs._48LightBulbCode.GDGuide2Objects2.length = 0;
gdjs._48LightBulbCode.GDGuideObjects1.length = 0;
gdjs._48LightBulbCode.GDGuideObjects2.length = 0;
gdjs._48LightBulbCode.GDbarObjects1.length = 0;
gdjs._48LightBulbCode.GDbarObjects2.length = 0;
gdjs._48LightBulbCode.GDicon2Objects1.length = 0;
gdjs._48LightBulbCode.GDicon2Objects2.length = 0;
gdjs._48LightBulbCode.GDiconObjects1.length = 0;
gdjs._48LightBulbCode.GDiconObjects2.length = 0;
gdjs._48LightBulbCode.GDNewObjectObjects1.length = 0;
gdjs._48LightBulbCode.GDNewObjectObjects2.length = 0;
gdjs._48LightBulbCode.GDhintObjects1.length = 0;
gdjs._48LightBulbCode.GDhintObjects2.length = 0;

gdjs._48LightBulbCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['_48LightBulbCode'] = gdjs._48LightBulbCode;
