gdjs._48blackCode = {};
gdjs._48blackCode.GDblackObjects1= [];
gdjs._48blackCode.GDblackObjects2= [];
gdjs._48blackCode.GDgoodluckObjects1= [];
gdjs._48blackCode.GDgoodluckObjects2= [];
gdjs._48blackCode.GDdotredObjects1= [];
gdjs._48blackCode.GDdotredObjects2= [];
gdjs._48blackCode.GDdotorange2Objects1= [];
gdjs._48blackCode.GDdotorange2Objects2= [];
gdjs._48blackCode.GDdotorangeObjects1= [];
gdjs._48blackCode.GDdotorangeObjects2= [];
gdjs._48blackCode.GDdotyellow2Objects1= [];
gdjs._48blackCode.GDdotyellow2Objects2= [];
gdjs._48blackCode.GDdotyellowObjects1= [];
gdjs._48blackCode.GDdotyellowObjects2= [];
gdjs._48blackCode.GDdotgreen2Objects1= [];
gdjs._48blackCode.GDdotgreen2Objects2= [];
gdjs._48blackCode.GDdotgreenObjects1= [];
gdjs._48blackCode.GDdotgreenObjects2= [];
gdjs._48blackCode.GDdotblue2Objects1= [];
gdjs._48blackCode.GDdotblue2Objects2= [];
gdjs._48blackCode.GDdotblueObjects1= [];
gdjs._48blackCode.GDdotblueObjects2= [];
gdjs._48blackCode.GDdotindigo2Objects1= [];
gdjs._48blackCode.GDdotindigo2Objects2= [];
gdjs._48blackCode.GDdotindigoObjects1= [];
gdjs._48blackCode.GDdotindigoObjects2= [];
gdjs._48blackCode.GDdotviolet2Objects1= [];
gdjs._48blackCode.GDdotviolet2Objects2= [];
gdjs._48blackCode.GDdotvioletObjects1= [];
gdjs._48blackCode.GDdotvioletObjects2= [];
gdjs._48blackCode.GDdotblack22Objects1= [];
gdjs._48blackCode.GDdotblack22Objects2= [];
gdjs._48blackCode.GDdotblack2Objects1= [];
gdjs._48blackCode.GDdotblack2Objects2= [];
gdjs._48blackCode.GDdotblackObjects1= [];
gdjs._48blackCode.GDdotblackObjects2= [];
gdjs._48blackCode.GDdotwhite22Objects1= [];
gdjs._48blackCode.GDdotwhite22Objects2= [];
gdjs._48blackCode.GDdotwhite2Objects1= [];
gdjs._48blackCode.GDdotwhite2Objects2= [];
gdjs._48blackCode.GDdotwhiteObjects1= [];
gdjs._48blackCode.GDdotwhiteObjects2= [];
gdjs._48blackCode.GDdotpinkObjects1= [];
gdjs._48blackCode.GDdotpinkObjects2= [];
gdjs._48blackCode.GDNext2Objects1= [];
gdjs._48blackCode.GDNext2Objects2= [];
gdjs._48blackCode.GDNextObjects1= [];
gdjs._48blackCode.GDNextObjects2= [];
gdjs._48blackCode.GDhintObjects1= [];
gdjs._48blackCode.GDhintObjects2= [];

gdjs._48blackCode.conditionTrue_0 = {val:false};
gdjs._48blackCode.condition0IsTrue_0 = {val:false};
gdjs._48blackCode.condition1IsTrue_0 = {val:false};
gdjs._48blackCode.condition2IsTrue_0 = {val:false};
gdjs._48blackCode.condition3IsTrue_0 = {val:false};


gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDNext2Objects1Objects = Hashtable.newFrom({"Next2": gdjs._48blackCode.GDNext2Objects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDgoodluckObjects1Objects = Hashtable.newFrom({"goodluck": gdjs._48blackCode.GDgoodluckObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotredObjects1Objects = Hashtable.newFrom({"dotred": gdjs._48blackCode.GDdotredObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotorange2Objects1Objects = Hashtable.newFrom({"dotorange2": gdjs._48blackCode.GDdotorange2Objects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotyellow2Objects1Objects = Hashtable.newFrom({"dotyellow2": gdjs._48blackCode.GDdotyellow2Objects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotgreen2Objects1Objects = Hashtable.newFrom({"dotgreen2": gdjs._48blackCode.GDdotgreen2Objects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotblue2Objects1Objects = Hashtable.newFrom({"dotblue2": gdjs._48blackCode.GDdotblue2Objects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotindigo2Objects1Objects = Hashtable.newFrom({"dotindigo2": gdjs._48blackCode.GDdotindigo2Objects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotviolet2Objects1Objects = Hashtable.newFrom({"dotviolet2": gdjs._48blackCode.GDdotviolet2Objects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotvioletObjects1Objects = Hashtable.newFrom({"dotviolet": gdjs._48blackCode.GDdotvioletObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotindigoObjects1Objects = Hashtable.newFrom({"dotindigo": gdjs._48blackCode.GDdotindigoObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotblueObjects1Objects = Hashtable.newFrom({"dotblue": gdjs._48blackCode.GDdotblueObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotgreenObjects1Objects = Hashtable.newFrom({"dotgreen": gdjs._48blackCode.GDdotgreenObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotyellowObjects1Objects = Hashtable.newFrom({"dotyellow": gdjs._48blackCode.GDdotyellowObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotorangeObjects1Objects = Hashtable.newFrom({"dotorange": gdjs._48blackCode.GDdotorangeObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotpinkObjects1Objects = Hashtable.newFrom({"dotpink": gdjs._48blackCode.GDdotpinkObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotblack22Objects1Objects = Hashtable.newFrom({"dotblack22": gdjs._48blackCode.GDdotblack22Objects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotblack2Objects1Objects = Hashtable.newFrom({"dotblack2": gdjs._48blackCode.GDdotblack2Objects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotblackObjects1Objects = Hashtable.newFrom({"dotblack": gdjs._48blackCode.GDdotblackObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotwhite22Objects1Objects = Hashtable.newFrom({"dotwhite22": gdjs._48blackCode.GDdotwhite22Objects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotwhite2Objects1Objects = Hashtable.newFrom({"dotwhite2": gdjs._48blackCode.GDdotwhite2Objects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotwhiteObjects1Objects = Hashtable.newFrom({"dotwhite": gdjs._48blackCode.GDdotwhiteObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotorangeObjects1Objects = Hashtable.newFrom({"dotorange": gdjs._48blackCode.GDdotorangeObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotyellowObjects1Objects = Hashtable.newFrom({"dotyellow": gdjs._48blackCode.GDdotyellowObjects1});gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotblueObjects1Objects = Hashtable.newFrom({"dotblue": gdjs._48blackCode.GDdotblueObjects1});gdjs._48blackCode.eventsList0xb4320 = function(runtimeScene) {

{


gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
{
gdjs._48blackCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "1");
}}
if (gdjs._48blackCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio\\Click-SoundBible.com-1387633738.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "1");
}}

}


{


gdjs._48blackCode.condition0IsTrue_0.val = false;
{
gdjs._48blackCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 2);
}if (gdjs._48blackCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


{


gdjs._48blackCode.condition0IsTrue_0.val = false;
{
gdjs._48blackCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1);
}if (gdjs._48blackCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Photon.mp3", 2, false, 100, 1);
}}

}


{


gdjs._48blackCode.condition0IsTrue_0.val = false;
{
gdjs._48blackCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._48blackCode.condition0IsTrue_0.val) {
gdjs._48blackCode.GDNextObjects1.createFrom(runtimeScene.getObjects("Next"));
gdjs._48blackCode.GDNext2Objects1.createFrom(runtimeScene.getObjects("Next2"));
gdjs._48blackCode.GDdotblue2Objects1.createFrom(runtimeScene.getObjects("dotblue2"));
gdjs._48blackCode.GDdotgreen2Objects1.createFrom(runtimeScene.getObjects("dotgreen2"));
gdjs._48blackCode.GDdotindigo2Objects1.createFrom(runtimeScene.getObjects("dotindigo2"));
gdjs._48blackCode.GDdotorange2Objects1.createFrom(runtimeScene.getObjects("dotorange2"));
gdjs._48blackCode.GDdotviolet2Objects1.createFrom(runtimeScene.getObjects("dotviolet2"));
gdjs._48blackCode.GDdotyellow2Objects1.createFrom(runtimeScene.getObjects("dotyellow2"));
{gdjs.adMob.loadBanner("ca-app-pub-6927019777720724/2829692216", "", true, true, true, false);
}{for(var i = 0, len = gdjs._48blackCode.GDNext2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDNext2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48blackCode.GDNextObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDNextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotorange2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotorange2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotyellow2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotyellow2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotgreen2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotgreen2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotblue2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotblue2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotindigo2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotindigo2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotviolet2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotviolet2Objects1[i].hide();
}
}}

}


{

gdjs._48blackCode.GDNext2Objects1.createFrom(runtimeScene.getObjects("Next2"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
gdjs._48blackCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDNext2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDNext2Objects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDNext2Objects1[i].isVisible() ) {
        gdjs._48blackCode.condition2IsTrue_0.val = true;
        gdjs._48blackCode.GDNext2Objects1[k] = gdjs._48blackCode.GDNext2Objects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDNext2Objects1.length = k;}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "NewScene", false);
}}

}


{

gdjs._48blackCode.GDgoodluckObjects1.createFrom(runtimeScene.getObjects("goodluck"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
{
gdjs._48blackCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDgoodluckObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48blackCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "0black", false);
}}

}


{

gdjs._48blackCode.GDdotredObjects1.createFrom(runtimeScene.getObjects("dotred"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
{
gdjs._48blackCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotredObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs._48blackCode.condition1IsTrue_0.val) {
gdjs._48blackCode.GDdotorange2Objects1.createFrom(runtimeScene.getObjects("dotorange2"));
{for(var i = 0, len = gdjs._48blackCode.GDdotorange2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotorange2Objects1[i].hide(false);
}
}}

}


{

gdjs._48blackCode.GDdotorange2Objects1.createFrom(runtimeScene.getObjects("dotorange2"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotorange2Objects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotorange2Objects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotorange2Objects1[k] = gdjs._48blackCode.GDdotorange2Objects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotorange2Objects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotorange2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotyellow2Objects1.createFrom(runtimeScene.getObjects("dotyellow2"));
{for(var i = 0, len = gdjs._48blackCode.GDdotyellow2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotyellow2Objects1[i].hide(false);
}
}}

}


{

gdjs._48blackCode.GDdotyellow2Objects1.createFrom(runtimeScene.getObjects("dotyellow2"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotyellow2Objects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotyellow2Objects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotyellow2Objects1[k] = gdjs._48blackCode.GDdotyellow2Objects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotyellow2Objects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotyellow2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotgreen2Objects1.createFrom(runtimeScene.getObjects("dotgreen2"));
{for(var i = 0, len = gdjs._48blackCode.GDdotgreen2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotgreen2Objects1[i].hide(false);
}
}}

}


{

gdjs._48blackCode.GDdotgreen2Objects1.createFrom(runtimeScene.getObjects("dotgreen2"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotgreen2Objects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotgreen2Objects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotgreen2Objects1[k] = gdjs._48blackCode.GDdotgreen2Objects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotgreen2Objects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotgreen2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotblue2Objects1.createFrom(runtimeScene.getObjects("dotblue2"));
{for(var i = 0, len = gdjs._48blackCode.GDdotblue2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotblue2Objects1[i].hide(false);
}
}}

}


{

gdjs._48blackCode.GDdotblue2Objects1.createFrom(runtimeScene.getObjects("dotblue2"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotblue2Objects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotblue2Objects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotblue2Objects1[k] = gdjs._48blackCode.GDdotblue2Objects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotblue2Objects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotblue2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotindigo2Objects1.createFrom(runtimeScene.getObjects("dotindigo2"));
{for(var i = 0, len = gdjs._48blackCode.GDdotindigo2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotindigo2Objects1[i].hide(false);
}
}}

}


{

gdjs._48blackCode.GDdotindigo2Objects1.createFrom(runtimeScene.getObjects("dotindigo2"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotindigo2Objects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotindigo2Objects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotindigo2Objects1[k] = gdjs._48blackCode.GDdotindigo2Objects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotindigo2Objects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotindigo2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotviolet2Objects1.createFrom(runtimeScene.getObjects("dotviolet2"));
{for(var i = 0, len = gdjs._48blackCode.GDdotviolet2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotviolet2Objects1[i].hide(false);
}
}}

}


{

gdjs._48blackCode.GDdotviolet2Objects1.createFrom(runtimeScene.getObjects("dotviolet2"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotviolet2Objects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotviolet2Objects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotviolet2Objects1[k] = gdjs._48blackCode.GDdotviolet2Objects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotviolet2Objects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotviolet2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDNextObjects1.createFrom(runtimeScene.getObjects("Next"));
gdjs._48blackCode.GDNext2Objects1.createFrom(runtimeScene.getObjects("Next2"));
{for(var i = 0, len = gdjs._48blackCode.GDNextObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDNextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs._48blackCode.GDNext2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDNext2Objects1[i].hide(false);
}
}}

}


{

gdjs._48blackCode.GDdotvioletObjects1.createFrom(runtimeScene.getObjects("dotviolet"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotvioletObjects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotvioletObjects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotvioletObjects1[k] = gdjs._48blackCode.GDdotvioletObjects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotvioletObjects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotvioletObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotblack22Objects1.createFrom(runtimeScene.getObjects("dotblack22"));
{for(var i = 0, len = gdjs._48blackCode.GDdotblack22Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotblack22Objects1[i].hide();
}
}}

}


{

gdjs._48blackCode.GDdotindigoObjects1.createFrom(runtimeScene.getObjects("dotindigo"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotindigoObjects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotindigoObjects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotindigoObjects1[k] = gdjs._48blackCode.GDdotindigoObjects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotindigoObjects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotindigoObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotblack2Objects1.createFrom(runtimeScene.getObjects("dotblack2"));
{for(var i = 0, len = gdjs._48blackCode.GDdotblack2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotblack2Objects1[i].hide();
}
}}

}


{

gdjs._48blackCode.GDdotblueObjects1.createFrom(runtimeScene.getObjects("dotblue"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotblueObjects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotblueObjects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotblueObjects1[k] = gdjs._48blackCode.GDdotblueObjects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotblueObjects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotblueObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotblackObjects1.createFrom(runtimeScene.getObjects("dotblack"));
{for(var i = 0, len = gdjs._48blackCode.GDdotblackObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotblackObjects1[i].hide();
}
}}

}


{

gdjs._48blackCode.GDdotgreenObjects1.createFrom(runtimeScene.getObjects("dotgreen"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotgreenObjects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotgreenObjects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotgreenObjects1[k] = gdjs._48blackCode.GDdotgreenObjects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotgreenObjects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotgreenObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotwhite22Objects1.createFrom(runtimeScene.getObjects("dotwhite22"));
{for(var i = 0, len = gdjs._48blackCode.GDdotwhite22Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotwhite22Objects1[i].hide();
}
}}

}


{

gdjs._48blackCode.GDdotyellowObjects1.createFrom(runtimeScene.getObjects("dotyellow"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotyellowObjects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotyellowObjects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotyellowObjects1[k] = gdjs._48blackCode.GDdotyellowObjects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotyellowObjects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotyellowObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotwhite2Objects1.createFrom(runtimeScene.getObjects("dotwhite2"));
{for(var i = 0, len = gdjs._48blackCode.GDdotwhite2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotwhite2Objects1[i].hide();
}
}}

}


{

gdjs._48blackCode.GDdotorangeObjects1.createFrom(runtimeScene.getObjects("dotorange"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotorangeObjects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotorangeObjects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotorangeObjects1[k] = gdjs._48blackCode.GDdotorangeObjects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotorangeObjects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotorangeObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotwhiteObjects1.createFrom(runtimeScene.getObjects("dotwhite"));
{for(var i = 0, len = gdjs._48blackCode.GDdotwhiteObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotwhiteObjects1[i].hide();
}
}}

}


{

gdjs._48blackCode.GDdotpinkObjects1.createFrom(runtimeScene.getObjects("dotpink"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotpinkObjects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotpinkObjects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotpinkObjects1[k] = gdjs._48blackCode.GDdotpinkObjects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotpinkObjects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotpinkObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotredObjects1.createFrom(runtimeScene.getObjects("dotred"));
gdjs._48blackCode.GDdotviolet2Objects1.createFrom(runtimeScene.getObjects("dotviolet2"));
{for(var i = 0, len = gdjs._48blackCode.GDdotredObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotredObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotviolet2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotviolet2Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs._48blackCode.GDdotblack22Objects1.createFrom(runtimeScene.getObjects("dotblack22"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotblack22Objects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotblack22Objects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotblack22Objects1[k] = gdjs._48blackCode.GDdotblack22Objects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotblack22Objects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotblack22Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotorange2Objects1.createFrom(runtimeScene.getObjects("dotorange2"));
gdjs._48blackCode.GDdotyellowObjects1.createFrom(runtimeScene.getObjects("dotyellow"));
{for(var i = 0, len = gdjs._48blackCode.GDdotorange2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotorange2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotyellowObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotyellowObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs._48blackCode.GDdotblack2Objects1.createFrom(runtimeScene.getObjects("dotblack2"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotblack2Objects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotblack2Objects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotblack2Objects1[k] = gdjs._48blackCode.GDdotblack2Objects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotblack2Objects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotblack2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotorangeObjects1.createFrom(runtimeScene.getObjects("dotorange"));
gdjs._48blackCode.GDdotwhiteObjects1.createFrom(runtimeScene.getObjects("dotwhite"));
{for(var i = 0, len = gdjs._48blackCode.GDdotorangeObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotorangeObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotwhiteObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotwhiteObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs._48blackCode.GDdotblackObjects1.createFrom(runtimeScene.getObjects("dotblack"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotblackObjects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotblackObjects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotblackObjects1[k] = gdjs._48blackCode.GDdotblackObjects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotblackObjects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotblackObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotblueObjects1.createFrom(runtimeScene.getObjects("dotblue"));
gdjs._48blackCode.GDdotwhiteObjects1.createFrom(runtimeScene.getObjects("dotwhite"));
{for(var i = 0, len = gdjs._48blackCode.GDdotwhiteObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotwhiteObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotblueObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotblueObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs._48blackCode.GDdotwhite22Objects1.createFrom(runtimeScene.getObjects("dotwhite22"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotwhite22Objects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotwhite22Objects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotwhite22Objects1[k] = gdjs._48blackCode.GDdotwhite22Objects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotwhite22Objects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotwhite22Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotblack22Objects1.createFrom(runtimeScene.getObjects("dotblack22"));
gdjs._48blackCode.GDdotviolet2Objects1.createFrom(runtimeScene.getObjects("dotviolet2"));
{for(var i = 0, len = gdjs._48blackCode.GDdotviolet2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotviolet2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotblack22Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotblack22Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs._48blackCode.GDdotwhite2Objects1.createFrom(runtimeScene.getObjects("dotwhite2"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotwhite2Objects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotwhite2Objects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotwhite2Objects1[k] = gdjs._48blackCode.GDdotwhite2Objects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotwhite2Objects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotwhite2Objects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotorangeObjects1.createFrom(runtimeScene.getObjects("dotorange"));
gdjs._48blackCode.GDdotpinkObjects1.createFrom(runtimeScene.getObjects("dotpink"));
{for(var i = 0, len = gdjs._48blackCode.GDdotorangeObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotorangeObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotpinkObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotpinkObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs._48blackCode.GDdotwhiteObjects1.createFrom(runtimeScene.getObjects("dotwhite"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._48blackCode.GDdotwhiteObjects1.length;i<l;++i) {
    if ( gdjs._48blackCode.GDdotwhiteObjects1[i].isVisible() ) {
        gdjs._48blackCode.condition0IsTrue_0.val = true;
        gdjs._48blackCode.GDdotwhiteObjects1[k] = gdjs._48blackCode.GDdotwhiteObjects1[i];
        ++k;
    }
}
gdjs._48blackCode.GDdotwhiteObjects1.length = k;}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotwhiteObjects1Objects, runtimeScene, true, false);
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
gdjs._48blackCode.GDdotgreen2Objects1.createFrom(runtimeScene.getObjects("dotgreen2"));
gdjs._48blackCode.GDdotindigoObjects1.createFrom(runtimeScene.getObjects("dotindigo"));
{for(var i = 0, len = gdjs._48blackCode.GDdotindigoObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotindigoObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs._48blackCode.GDdotgreen2Objects1.length ;i < len;++i) {
    gdjs._48blackCode.GDdotgreen2Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs._48blackCode.GDdotblueObjects1.createFrom(runtimeScene.getObjects("dotblue"));
gdjs._48blackCode.GDdotorangeObjects1.createFrom(runtimeScene.getObjects("dotorange"));
gdjs._48blackCode.GDdotyellowObjects1.createFrom(runtimeScene.getObjects("dotyellow"));

gdjs._48blackCode.condition0IsTrue_0.val = false;
gdjs._48blackCode.condition1IsTrue_0.val = false;
gdjs._48blackCode.condition2IsTrue_0.val = false;
{
gdjs._48blackCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotorangeObjects1Objects) == 0;
}if ( gdjs._48blackCode.condition0IsTrue_0.val ) {
{
gdjs._48blackCode.condition1IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotyellowObjects1Objects) == 0;
}if ( gdjs._48blackCode.condition1IsTrue_0.val ) {
{
gdjs._48blackCode.condition2IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs._48blackCode.mapOfGDgdjs_46_9548blackCode_46GDdotblueObjects1Objects) == 0;
}}
}
if (gdjs._48blackCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "0black", false);
}}

}


{


gdjs._48blackCode.condition0IsTrue_0.val = false;
{
gdjs._48blackCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 60, "60");
}if (gdjs._48blackCode.condition0IsTrue_0.val) {
gdjs._48blackCode.GDhintObjects1.createFrom(runtimeScene.getObjects("hint"));
{for(var i = 0, len = gdjs._48blackCode.GDhintObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDhintObjects1[i].hide(false);
}
}}

}


{


gdjs._48blackCode.condition0IsTrue_0.val = false;
{
gdjs._48blackCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._48blackCode.condition0IsTrue_0.val) {
gdjs._48blackCode.GDhintObjects1.createFrom(runtimeScene.getObjects("hint"));
{for(var i = 0, len = gdjs._48blackCode.GDhintObjects1.length ;i < len;++i) {
    gdjs._48blackCode.GDhintObjects1[i].hide();
}
}}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


}; //End of gdjs._48blackCode.eventsList0xb4320


gdjs._48blackCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._48blackCode.GDblackObjects1.length = 0;
gdjs._48blackCode.GDblackObjects2.length = 0;
gdjs._48blackCode.GDgoodluckObjects1.length = 0;
gdjs._48blackCode.GDgoodluckObjects2.length = 0;
gdjs._48blackCode.GDdotredObjects1.length = 0;
gdjs._48blackCode.GDdotredObjects2.length = 0;
gdjs._48blackCode.GDdotorange2Objects1.length = 0;
gdjs._48blackCode.GDdotorange2Objects2.length = 0;
gdjs._48blackCode.GDdotorangeObjects1.length = 0;
gdjs._48blackCode.GDdotorangeObjects2.length = 0;
gdjs._48blackCode.GDdotyellow2Objects1.length = 0;
gdjs._48blackCode.GDdotyellow2Objects2.length = 0;
gdjs._48blackCode.GDdotyellowObjects1.length = 0;
gdjs._48blackCode.GDdotyellowObjects2.length = 0;
gdjs._48blackCode.GDdotgreen2Objects1.length = 0;
gdjs._48blackCode.GDdotgreen2Objects2.length = 0;
gdjs._48blackCode.GDdotgreenObjects1.length = 0;
gdjs._48blackCode.GDdotgreenObjects2.length = 0;
gdjs._48blackCode.GDdotblue2Objects1.length = 0;
gdjs._48blackCode.GDdotblue2Objects2.length = 0;
gdjs._48blackCode.GDdotblueObjects1.length = 0;
gdjs._48blackCode.GDdotblueObjects2.length = 0;
gdjs._48blackCode.GDdotindigo2Objects1.length = 0;
gdjs._48blackCode.GDdotindigo2Objects2.length = 0;
gdjs._48blackCode.GDdotindigoObjects1.length = 0;
gdjs._48blackCode.GDdotindigoObjects2.length = 0;
gdjs._48blackCode.GDdotviolet2Objects1.length = 0;
gdjs._48blackCode.GDdotviolet2Objects2.length = 0;
gdjs._48blackCode.GDdotvioletObjects1.length = 0;
gdjs._48blackCode.GDdotvioletObjects2.length = 0;
gdjs._48blackCode.GDdotblack22Objects1.length = 0;
gdjs._48blackCode.GDdotblack22Objects2.length = 0;
gdjs._48blackCode.GDdotblack2Objects1.length = 0;
gdjs._48blackCode.GDdotblack2Objects2.length = 0;
gdjs._48blackCode.GDdotblackObjects1.length = 0;
gdjs._48blackCode.GDdotblackObjects2.length = 0;
gdjs._48blackCode.GDdotwhite22Objects1.length = 0;
gdjs._48blackCode.GDdotwhite22Objects2.length = 0;
gdjs._48blackCode.GDdotwhite2Objects1.length = 0;
gdjs._48blackCode.GDdotwhite2Objects2.length = 0;
gdjs._48blackCode.GDdotwhiteObjects1.length = 0;
gdjs._48blackCode.GDdotwhiteObjects2.length = 0;
gdjs._48blackCode.GDdotpinkObjects1.length = 0;
gdjs._48blackCode.GDdotpinkObjects2.length = 0;
gdjs._48blackCode.GDNext2Objects1.length = 0;
gdjs._48blackCode.GDNext2Objects2.length = 0;
gdjs._48blackCode.GDNextObjects1.length = 0;
gdjs._48blackCode.GDNextObjects2.length = 0;
gdjs._48blackCode.GDhintObjects1.length = 0;
gdjs._48blackCode.GDhintObjects2.length = 0;

gdjs._48blackCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['_48blackCode'] = gdjs._48blackCode;
