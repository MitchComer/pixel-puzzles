gdjs.NewSceneCode = {};
gdjs.NewSceneCode.GDbackgroundObjects1= [];
gdjs.NewSceneCode.GDbackgroundObjects2= [];
gdjs.NewSceneCode.GDguideObjects1= [];
gdjs.NewSceneCode.GDguideObjects2= [];
gdjs.NewSceneCode.GDnext2Objects1= [];
gdjs.NewSceneCode.GDnext2Objects2= [];
gdjs.NewSceneCode.GDnextObjects1= [];
gdjs.NewSceneCode.GDnextObjects2= [];
gdjs.NewSceneCode.GDlolObjects1= [];
gdjs.NewSceneCode.GDlolObjects2= [];
gdjs.NewSceneCode.GDNewObjectObjects1= [];
gdjs.NewSceneCode.GDNewObjectObjects2= [];
gdjs.NewSceneCode.GDhintObjects1= [];
gdjs.NewSceneCode.GDhintObjects2= [];

gdjs.NewSceneCode.conditionTrue_0 = {val:false};
gdjs.NewSceneCode.condition0IsTrue_0 = {val:false};
gdjs.NewSceneCode.condition1IsTrue_0 = {val:false};
gdjs.NewSceneCode.condition2IsTrue_0 = {val:false};


gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDnext2Objects1Objects = Hashtable.newFrom({"next2": gdjs.NewSceneCode.GDnext2Objects1});gdjs.NewSceneCode.eventsList0xb4320 = function(runtimeScene) {

{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
{gdjs.adMob.loadBanner("ca-app-pub-6927019777720724/2829692216", "", true, true, true, false);
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
gdjs.NewSceneCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "1");
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio\\Click-SoundBible.com-1387633738.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "1");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 2);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Photon.mp3", 2, false, 100, 1);
}}

}


{

gdjs.NewSceneCode.GDnext2Objects1.createFrom(runtimeScene.getObjects("next2"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDnext2Objects1Objects, runtimeScene, true, false);
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
gdjs.NewSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "0LightBulb", false);
}}

}


}; //End of gdjs.NewSceneCode.eventsList0xb4320


gdjs.NewSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.NewSceneCode.GDbackgroundObjects1.length = 0;
gdjs.NewSceneCode.GDbackgroundObjects2.length = 0;
gdjs.NewSceneCode.GDguideObjects1.length = 0;
gdjs.NewSceneCode.GDguideObjects2.length = 0;
gdjs.NewSceneCode.GDnext2Objects1.length = 0;
gdjs.NewSceneCode.GDnext2Objects2.length = 0;
gdjs.NewSceneCode.GDnextObjects1.length = 0;
gdjs.NewSceneCode.GDnextObjects2.length = 0;
gdjs.NewSceneCode.GDlolObjects1.length = 0;
gdjs.NewSceneCode.GDlolObjects2.length = 0;
gdjs.NewSceneCode.GDNewObjectObjects1.length = 0;
gdjs.NewSceneCode.GDNewObjectObjects2.length = 0;
gdjs.NewSceneCode.GDhintObjects1.length = 0;
gdjs.NewSceneCode.GDhintObjects2.length = 0;

gdjs.NewSceneCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['NewSceneCode'] = gdjs.NewSceneCode;
