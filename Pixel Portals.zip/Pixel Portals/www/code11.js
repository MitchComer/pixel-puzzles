gdjs.ggCode = {};
gdjs.ggCode.GDNewObjectObjects1= [];
gdjs.ggCode.GDNewObjectObjects2= [];
gdjs.ggCode.GDggObjects1= [];
gdjs.ggCode.GDggObjects2= [];
gdjs.ggCode.GDhome2Objects1= [];
gdjs.ggCode.GDhome2Objects2= [];
gdjs.ggCode.GDhomeObjects1= [];
gdjs.ggCode.GDhomeObjects2= [];

gdjs.ggCode.conditionTrue_0 = {val:false};
gdjs.ggCode.condition0IsTrue_0 = {val:false};
gdjs.ggCode.condition1IsTrue_0 = {val:false};
gdjs.ggCode.condition2IsTrue_0 = {val:false};


gdjs.ggCode.mapOfGDgdjs_46ggCode_46GDhome2Objects1Objects = Hashtable.newFrom({"home2": gdjs.ggCode.GDhome2Objects1});gdjs.ggCode.eventsList0xb4320 = function(runtimeScene) {

{


gdjs.ggCode.condition0IsTrue_0.val = false;
{
gdjs.ggCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.ggCode.condition0IsTrue_0.val) {
{gdjs.adMob.loadBanner("ca-app-pub-6927019777720724/2829692216", "", true, true, true, false);
}}

}


{


gdjs.ggCode.condition0IsTrue_0.val = false;
gdjs.ggCode.condition1IsTrue_0.val = false;
{
gdjs.ggCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.ggCode.condition0IsTrue_0.val ) {
{
gdjs.ggCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.2, "1");
}}
if (gdjs.ggCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "audio\\Click-SoundBible.com-1387633738.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "1");
}}

}


{


gdjs.ggCode.condition0IsTrue_0.val = false;
{
gdjs.ggCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 2);
}if (gdjs.ggCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Columbus.mp3", 1, false, 100, 1);
}}

}


{


gdjs.ggCode.condition0IsTrue_0.val = false;
{
gdjs.ggCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1);
}if (gdjs.ggCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio\\Photon.mp3", 2, false, 100, 1);
}}

}


{

gdjs.ggCode.GDhome2Objects1.createFrom(runtimeScene.getObjects("home2"));

gdjs.ggCode.condition0IsTrue_0.val = false;
gdjs.ggCode.condition1IsTrue_0.val = false;
{
gdjs.ggCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ggCode.mapOfGDgdjs_46ggCode_46GDhome2Objects1Objects, runtimeScene, true, false);
}if ( gdjs.ggCode.condition0IsTrue_0.val ) {
{
gdjs.ggCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.ggCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Intro", false);
}}

}


}; //End of gdjs.ggCode.eventsList0xb4320


gdjs.ggCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ggCode.GDNewObjectObjects1.length = 0;
gdjs.ggCode.GDNewObjectObjects2.length = 0;
gdjs.ggCode.GDggObjects1.length = 0;
gdjs.ggCode.GDggObjects2.length = 0;
gdjs.ggCode.GDhome2Objects1.length = 0;
gdjs.ggCode.GDhome2Objects2.length = 0;
gdjs.ggCode.GDhomeObjects1.length = 0;
gdjs.ggCode.GDhomeObjects2.length = 0;

gdjs.ggCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['ggCode'] = gdjs.ggCode;
